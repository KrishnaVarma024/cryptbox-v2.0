"""
Cryptbox 2.0 - Cryptographic Utilities

Provides helper functions for cryptographic operations including:
- Key derivation (PBKDF2)
- Salt generation
- Hash functions
- Random data generation
"""

import hashlib
import os
from typing import Optional
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes


def derive_key(password: str, salt: bytes, key_length: int = 32, iterations: int = 100000) -> bytes:
    """
    Derive a cryptographic key from a password using PBKDF2-SHA256.
    
    This is the recommended way to convert passwords into encryption keys.
    Uses 100,000 iterations by default for strong security.
    
    Args:
        password: Password string to derive key from
        salt: Salt bytes for key derivation (should be unique per use)
        key_length: Length of derived key in bytes (default: 32 for AES-256)
        iterations: Number of PBKDF2 iterations (default: 100000)
        
    Returns:
        Derived key as bytes
        
    Example:
        >>> salt = generate_salt()
        >>> key = derive_key("my_password", salt)
        >>> len(key)
        32
    """
    if isinstance(password, str):
        password = password.encode('utf-8')
    
    # Use SHA256 module (not the function) for PBKDF2
    from Crypto.Hash import SHA256
    key = PBKDF2(password, salt, dkLen=key_length, count=iterations, hmac_hash_module=SHA256)
    return key


def generate_salt(length: int = 16) -> bytes:
    """
    Generate a cryptographically secure random salt.
    
    Args:
        length: Length of salt in bytes (default: 16)
        
    Returns:
        Random salt bytes
        
    Example:
        >>> salt = generate_salt()
        >>> len(salt)
        16
    """
    return get_random_bytes(length)


def generate_random_bytes(length: int) -> bytes:
    """
    Generate cryptographically secure random bytes.
    
    Args:
        length: Number of random bytes to generate
        
    Returns:
        Random bytes
    """
    return get_random_bytes(length)


def hash_sha256(data: bytes) -> bytes:
    """
    Compute SHA-256 hash of data.
    
    Args:
        data: Data to hash
        
    Returns:
        SHA-256 hash bytes
    """
    return hashlib.sha256(data).digest()


def hash_sha256_hex(data: bytes) -> str:
    """
    Compute SHA-256 hash of data and return as hex string.
    
    Args:
        data: Data to hash
        
    Returns:
        SHA-256 hash as hex string
    """
    return hashlib.sha256(data).hexdigest()


def hash_file_sha256(file_path: str) -> str:
    """
    Compute SHA-256 hash of a file.
    
    Args:
        file_path: Path to file
        
    Returns:
        SHA-256 hash as hex string
    """
    sha256_hash = hashlib.sha256()
    
    with open(file_path, "rb") as f:
        # Read file in chunks to handle large files
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    
    return sha256_hash.hexdigest()


def constant_time_compare(a: bytes, b: bytes) -> bool:
    """
    Compare two byte strings in constant time to prevent timing attacks.
    
    Args:
        a: First byte string
        b: Second byte string
        
    Returns:
        True if equal, False otherwise
    """
    if len(a) != len(b):
        return False
    
    result = 0
    for x, y in zip(a, b):
        result |= x ^ y
    
    return result == 0


def generate_key_from_password(password: str, salt: Optional[bytes] = None) -> tuple:
    """
    Generate an encryption key from a password.
    If no salt provided, generates a new one.
    
    Args:
        password: Password to derive key from
        salt: Optional salt (if None, generates new salt)
        
    Returns:
        Tuple of (key, salt)
        
    Example:
        >>> key, salt = generate_key_from_password("my_password")
        >>> # Later, derive the same key with the same salt
        >>> same_key, _ = generate_key_from_password("my_password", salt)
        >>> key == same_key
        True
    """
    if salt is None:
        salt = generate_salt()
    
    key = derive_key(password, salt)
    return key, salt


# Example usage and testing
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - Crypto Utilities Demo ===\n")
    
    # Test key derivation
    print("1. Key Derivation (PBKDF2):")
    password = "my_secure_password"
    salt = generate_salt()
    
    key = derive_key(password, salt)
    print(f"   Password: {password}")
    print(f"   Salt (hex): {salt.hex()}")
    print(f"   Derived Key (hex): {key.hex()}")
    print(f"   Key length: {len(key)} bytes")
    
    # Verify same password + salt = same key
    key2 = derive_key(password, salt)
    print(f"   Keys match: {key == key2}")
    print()
    
    # Test with different salt
    print("2. Different Salt = Different Key:")
    salt2 = generate_salt()
    key3 = derive_key(password, salt2)
    print(f"   Same password, different salt")
    print(f"   Keys different: {key != key3}")
    print()
    
    # Test random generation
    print("3. Random Generation:")
    random_data = generate_random_bytes(32)
    print(f"   Random bytes (hex): {random_data.hex()}")
    print(f"   Length: {len(random_data)} bytes")
    print()
    
    # Test hashing
    print("4. SHA-256 Hashing:")
    data = b"Hello, Cryptbox 2.0!"
    hash_result = hash_sha256(data)
    hash_hex = hash_sha256_hex(data)
    print(f"   Data: {data.decode()}")
    print(f"   Hash (hex): {hash_hex}")
    print(f"   Hash length: {len(hash_result)} bytes")
    print()
    
    # Test file hashing
    print("5. File Hashing:")
    # Create test file
    test_file = "/tmp/test_crypto_utils.txt"
    with open(test_file, "w") as f:
        f.write("Test file for hashing")
    
    file_hash = hash_file_sha256(test_file)
    print(f"   File: {test_file}")
    print(f"   SHA-256: {file_hash}")
    
    # Cleanup
    os.remove(test_file)
    print()
    
    # Test constant time compare
    print("6. Constant Time Comparison:")
    value1 = b"secret_value"
    value2 = b"secret_value"
    value3 = b"other_value!"
    
    print(f"   Compare equal values: {constant_time_compare(value1, value2)}")
    print(f"   Compare different values: {constant_time_compare(value1, value3)}")
    print()
    
    # Test generate_key_from_password
    print("7. Generate Key from Password:")
    key, salt = generate_key_from_password("test_password")
    print(f"   Generated key (hex): {key.hex()[:32]}...")
    print(f"   Generated salt (hex): {salt.hex()}")
    
    # Regenerate with same salt
    key_again, _ = generate_key_from_password("test_password", salt)
    print(f"   Keys match with same salt: {key == key_again}")
    
    print("\n✅ All crypto utilities working correctly!")