"""
Cryptbox 2.0 - Web GUI Dashboard

Flask-based web interface for Cryptbox operations:
- File encryption/decryption
- Key management
- Secure sharing
- System status
- File browser
"""

import os
import sys
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, session
from flask_cors import CORS
from werkzeug.utils import secure_filename
import secrets

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from cryptbox.encryption import FileEncryptor
from cryptbox.key_manager import RSAKeyManager
from cryptbox.signature import DigitalSignature
from cryptbox.config_manager import ConfigManager
from cryptbox.metadata import MetadataManager
from cryptbox.sharing import SecureSharing, KeyExchange

# Initialize Flask app
app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
CORS(app)

# Configuration
# Determine real encrypted storage folder
BASE_DIR = Path(__file__).resolve().parents[1]
ENCRYPTED_FOLDER = BASE_DIR / "dropbox_sync" / "cryptbox" / "__enc__"
ENCRYPTED_FOLDER.mkdir(exist_ok=True, parents=True)

# Temporary upload folder
UPLOAD_FOLDER = Path('/tmp/cryptbox_uploads')
UPLOAD_FOLDER.mkdir(exist_ok=True, parents=True)


app.config['UPLOAD_FOLDER'] = str(UPLOAD_FOLDER)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max

# Initialize Cryptbox components
encryptor = FileEncryptor()
config_manager = ConfigManager()
key_manager = None
signature_manager = None

# Check if keys exist
key_dir = Path.home() / ".cryptbox" / "keys"
private_key_path = key_dir / "private_key.pem"
public_key_path = key_dir / "public_key.pem"

if private_key_path.exists() and public_key_path.exists():
    key_manager = RSAKeyManager(str(private_key_path), str(public_key_path))
    key_manager.load_keys()
    signature_manager = DigitalSignature(key_manager)


# Routes

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')


@app.route('/api/status')
def get_status():
    """Get system status"""
    try:
        has_keys = key_manager is not None
        has_config = config_manager.get_default_password() is not None
        
        status = {
            'initialized': has_keys and has_config,
            'has_keys': has_keys,
            'has_config': has_config,
            'mount_point': config_manager.get_mount_point() if has_config else None,
            'encrypted_storage': config_manager.get_encrypted_storage() if has_config else None,
            'num_files': len(config_manager.list_encrypted_files()) if has_config else 0
        }
        
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/initialize', methods=['POST'])
def initialize():
    """Initialize Cryptbox with password"""
    try:
        data = request.json
        password = data.get('password')
        
        if not password:
            return jsonify({'error': 'Password required'}), 400
        
        # Generate keys if not exists
        global key_manager, signature_manager
        
        if not key_manager:
            key_manager = RSAKeyManager(str(private_key_path), str(public_key_path))
            key_manager.generate_keys()
            key_manager.save_keys()
            signature_manager = DigitalSignature(key_manager)
        
        # Set default password
        config_manager.set_default_password(password)
        
        return jsonify({'success': True, 'message': 'Cryptbox initialized successfully'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/encrypt', methods=['POST'])
def encrypt_file():
    """Encrypt uploaded file"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        password = request.form.get('password')
        
        if not password:
            password = config_manager.get_default_password()
            if not password:
                return jsonify({'error': 'No password provided'}), 400
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        upload_path = UPLOAD_FOLDER / filename
        file.save(str(upload_path))
        
        # Encrypt file
        encrypted_filename = f"{filename}.enc"
        encrypted_path = ENCRYPTED_FOLDER / encrypted_filename
        
        encryptor.encrypt_file(str(upload_path), str(encrypted_path), password)
        
        # Sign if keys available
        signature = None
        if signature_manager:
            signature = signature_manager.sign_file(str(encrypted_path))
        
        # Clean up uploaded file
        upload_path.unlink()
        
        return jsonify({
            'success': True,
            'message': 'File encrypted successfully',
            'filename': encrypted_filename,
            'has_signature': signature is not None
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/decrypt', methods=['POST'])
def decrypt_file():
    """Decrypt file"""
    try:
        data = request.json
        filename = data.get('filename')
        password = data.get('password')
        
        if not filename or not password:
            return jsonify({'error': 'Filename and password required'}), 400
        
        encrypted_path = ENCRYPTED_FOLDER / filename
        if not encrypted_path.exists():
            return jsonify({'error': 'File not found'}), 404
        
        # Verify signature if available
        signature_valid = None
        if signature_manager:
            try:
                signature_valid = signature_manager.verify_file(str(encrypted_path))
            except:
                signature_valid = False
        
        # Decrypt file
        decrypted_filename = filename.replace('.enc', '')
        decrypted_path = UPLOAD_FOLDER / decrypted_filename
        
        encryptor.decrypt_file(str(encrypted_path), str(decrypted_path), password)
        
        return jsonify({
            'success': True,
            'message': 'File decrypted successfully',
            'filename': decrypted_filename,
            'signature_valid': signature_valid,
            'download_url': f'/api/download/{decrypted_filename}'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/download/<filename>')
def download_file(filename):
    """Download decrypted file"""
    try:
        file_path = UPLOAD_FOLDER / secure_filename(filename)
        if not file_path.exists():
            return jsonify({'error': 'File not found'}), 404
        
        return send_file(str(file_path), as_attachment=True, download_name=filename)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/files')
def list_files():
    """List encrypted files"""
    try:
        files = []
        for file_path in ENCRYPTED_FOLDER.glob('*.enc'):
            stat = file_path.stat()
            
            # Check if signature exists
            sig_path = Path(str(file_path) + '.sig')
            has_signature = sig_path.exists()
            
            files.append({
                'name': file_path.name,
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'has_signature': has_signature
            })
        
        return jsonify({'files': files})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/delete/<filename>', methods=['DELETE'])
def delete_file(filename):
    """Delete encrypted file"""
    try:
        file_path = ENCRYPTED_FOLDER / secure_filename(filename)
        sig_path = Path(str(file_path) + '.sig')
        
        if file_path.exists():
            file_path.unlink()
        
        if sig_path.exists():
            sig_path.unlink()
        
        return jsonify({'success': True, 'message': 'File deleted'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export-key', methods=['POST'])
def export_public_key():
    """Export public key"""
    try:
        if not key_manager:
            return jsonify({'error': 'Keys not initialized'}), 400
        
        data = request.json
        name = data.get('name', 'User')
        email = data.get('email', '')
        
        # Export key to temp file
        export_path = UPLOAD_FOLDER / 'public_key.json'
        KeyExchange.export_public_key(
            key_manager,
            str(export_path),
            {'name': name, 'email': email}
        )
        
        return send_file(str(export_path), as_attachment=True, download_name='my_public_key.json')
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/share', methods=['POST'])
def share_file():
    """Create sharing bundle"""
    try:
        if not key_manager:
            return jsonify({'error': 'Keys not initialized'}), 400
        
        # Get recipient public key file
        if 'recipient_key' not in request.files:
            return jsonify({'error': 'Recipient key required'}), 400
        
        recipient_key_file = request.files['recipient_key']
        filename = request.form.get('filename')
        password = request.form.get('password')
        
        if not filename or not password:
            return jsonify({'error': 'Filename and password required'}), 400
        
        # Save recipient key
        key_path = UPLOAD_FOLDER / 'recipient_key.json'
        recipient_key_file.save(str(key_path))
        
        # Import recipient key
        recipient_pub_key, recipient_info = KeyExchange.import_public_key(str(key_path))
        
        # Create sharing manager
        sharing_manager = SecureSharing(key_manager, config_manager)
        
        # Set file password in config
        file_path = f"/encrypted/{filename}"
        config_manager.set_file_password(file_path, password)
        
        # Create sharing bundle
        bundle = sharing_manager.create_sharing_bundle(
            file_path,
            password,
            [recipient_pub_key]
        )
        
        # Save bundle
        bundle_path = UPLOAD_FOLDER / f"{filename}.sharing_bundle.json"
        sharing_manager.save_sharing_bundle(bundle, str(bundle_path))
        
        # Cleanup
        key_path.unlink()
        
        return send_file(
            str(bundle_path),
            as_attachment=True,
            download_name=f"{filename}.sharing_bundle.json"
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/receive', methods=['POST'])
def receive_shared_file():
    """Receive shared file"""
    try:
        if not key_manager:
            return jsonify({'error': 'Keys not initialized'}), 400
        
        # Get sharing bundle
        if 'bundle' not in request.files:
            return jsonify({'error': 'Sharing bundle required'}), 400
        
        bundle_file = request.files['bundle']
        filename = request.form.get('filename')
        
        if not filename:
            return jsonify({'error': 'Filename required'}), 400
        
        # Save bundle
        bundle_path = UPLOAD_FOLDER / 'sharing_bundle.json'
        bundle_file.save(str(bundle_path))
        
        # Create sharing manager
        sharing_manager = SecureSharing(key_manager, config_manager)
        
        # Receive file
        encrypted_path = str(ENCRYPTED_FOLDER / filename)
        success = sharing_manager.receive_shared_file(str(bundle_path), encrypted_path)
        
        # Cleanup
        bundle_path.unlink()
        
        if success:
            return jsonify({
                'success': True,
                'message': 'File received successfully. Password configured.'
            })
        else:
            return jsonify({'error': 'Failed to receive file'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/stats')
def get_stats():
    """Get encryption statistics"""
    try:
        total_files = len(list(ENCRYPTED_FOLDER.glob('*.enc')))
        total_size = sum(f.stat().st_size for f in ENCRYPTED_FOLDER.glob('*.enc'))
        
        signed_files = len(list(ENCRYPTED_FOLDER.glob('*.sig')))
        
        stats = {
            'total_files': total_files,
            'total_size': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'signed_files': signed_files,
            'signature_percentage': round((signed_files / total_files * 100) if total_files > 0 else 0, 1)
        }
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
# --- Add this to dashboard.py near the Flask app initialization ---

# Prevent aggressive caching by browsers (useful during development)
@app.after_request
def add_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route('/api/download-encrypted/<filename>')
def download_encrypted(filename):
    """Download encrypted file directly"""
    try:
        from werkzeug.utils import secure_filename

        file_path = ENCRYPTED_FOLDER / secure_filename(filename)

        if not file_path.exists():
            return jsonify({'error': 'Encrypted file not found'}), 404

        return send_file(
            str(file_path),
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Error handlers

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


# Main

def main():
    """Run the dashboard"""
    print("\n" + "="*60)
    print("🔐 CRYPTBOX 2.0 - WEB DASHBOARD")
    print("="*60)
    print("\nStarting web interface...")
    print(f"Dashboard URL: http://localhost:5000")
    print("\nPress Ctrl+C to stop\n")
    
    app.run(host='0.0.0.0', port=8080, debug=True)


if __name__ == '__main__':
    main()