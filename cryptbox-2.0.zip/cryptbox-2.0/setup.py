"""
Cryptbox 2.0 - Setup Configuration
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

setup(
    name="cryptbox",
    version="2.0.0",
    description="Encrypted File System for Secure Cloud Storage",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/cryptbox-2.0",
    
    packages=find_packages(exclude=["tests", "docs"]),
    
    install_requires=[
        "fusepy>=3.0.1",
        "pycryptodome>=3.19.0",
        "cryptography>=41.0.7",
        "click>=8.1.7",
        "colorama>=0.4.6",
    ],
    
    extras_require={
        "gui": [
            "flask>=3.0.0",
            "flask-cors>=4.0.0",
        ],
        "dev": [
            "pytest>=7.4.3",
            "pytest-cov>=4.1.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    
    entry_points={
        "console_scripts": [
            "cryptbox=cryptbox.main:main",
        ],
    },
    
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "Topic :: Security :: Cryptography",
        "Topic :: System :: Filesystems",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
    ],
    
    python_requires=">=3.8",
    
    keywords="encryption filesystem fuse cryptography cloud-storage security",
    
    project_urls={
        "Documentation": "https://github.com/yourusername/cryptbox-2.0/docs",
        "Source": "https://github.com/yourusername/cryptbox-2.0",
        "Tracker": "https://github.com/yourusername/cryptbox-2.0/issues",
    },
)