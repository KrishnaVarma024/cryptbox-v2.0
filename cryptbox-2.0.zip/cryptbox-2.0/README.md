# Cryptbox 2.0 - Encrypted File System for Secure Cloud Storage

## Overview
Cryptbox 2.0 is an enhanced encrypted file system that protects your data in cloud storage services like Dropbox using strong cryptography.

## Features
- **AES-256-GCM**: Authenticated encryption for file contents
- **RSA-2048**: Secure key management
- **SHA-256/PBKDF2**: Strong key derivation
- **Digital Signatures**: File integrity verification
- **Metadata Encryption**: Protect file names and attributes
- **Directory Support**: Encrypt entire folder structures
- **Secure Sharing**: Safe password distribution

## Installation
```bash
pip install -r requirements.txt
python setup.py install
```

## Quick Start
```bash
# Generate keys
cryptbox init

# Mount filesystem
cryptbox mount /path/to/mount/point

# Unmount
cryptbox unmount
```

## Project Structure
See `docs/architecture.md` for detailed documentation.

## Security
See `docs/security_analysis.md` for threat model and security guarantees.python --version







## 🎨 GUI Dashboard

Cryptbox 2.0 includes a beautiful web-based dashboard for easy file management.

### Launch Dashboard
```bash
python gui/dashboard.py
```

Open browser to: **http://localhost:5000**

### Dashboard Features

- 🔒 **Drag & Drop Encryption**: Easy file encryption
- 🔓 **One-Click Decryption**: Decrypt and download instantly
- 📁 **File Browser**: View all encrypted files
- 🤝 **Secure Sharing**: Share files with visual interface
- 📥 **Receive Files**: Simple file receiving workflow
- 🔑 **Key Export**: Export public keys easily
- 📊 **Real-Time Stats**: Monitor encryption activity

### Screenshots

![Dashboard](docs/screenshots/dashboard.png)

See [GUI_GUIDE.md](docs/GUI_GUIDE.md) for complete documentation.