#!/usr/bin/env python3
"""
Cryptbox 2.0 - Presentation Demo Script
Safe demonstration without FUSE mounting
Shows all key features for academic presentation
"""

import sys
import time
from pathlib import Path
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from cryptbox.key_manager import RSAKeyManager
from cryptbox.encryption import FileEncryptor
from cryptbox.signature import DigitalSignature
from cryptbox.config_manager import ConfigManager
from cryptbox.metadata import MetadataManager
from cryptbox.file_manager import DecryptedFileManager
from cryptbox.sharing import SecureSharing, KeyExchange


def print_header(title):
    """Print section header"""
    print(f"\n{Fore.CYAN}{'='*70}")
    print(f"{Fore.CYAN}{title.center(70)}")
    print(f"{Fore.CYAN}{'='*70}\n")


def print_step(step_num, description):
    """Print step description"""
    print(f"{Fore.YELLOW}[Step {step_num}] {description}")
    time.sleep(0.5)


def print_success(message):
    """Print success message"""
    print(f"{Fore.GREEN}   ✓ {message}")


def print_info(message):
    """Print info message"""
    print(f"{Fore.WHITE}   {message}")


def demo_encryption_basics():
    """Demonstrate basic encryption/decryption"""
    print_header("DEMO 1: AES-256-GCM ENCRYPTION")
    
    print_step(1, "Initialize File Encryptor")
    encryptor = FileEncryptor()
    print_success("FileEncryptor initialized with AES-256-GCM")
    
    print_step(2, "Create test file with confidential data")
    test_dir = Path("/tmp/cryptbox_demo")
    test_dir.mkdir(exist_ok=True)
    
    original_file = test_dir / "confidential_report.txt"
    original_content = """
CONFIDENTIAL COMPANY REPORT
===========================
Q4 Revenue: $10M
New Product Launch: Project Phoenix
Strategic Partners: [REDACTED]
    """
    original_file.write_text(original_content)
    print_info(f"File created: {original_file}")
    print_info(f"Content preview: {original_content[:50]}...")
    
    print_step(3, "Encrypt file with password")
    password = "SecurePassword123!"
    encrypted_file = test_dir / "confidential_report.enc"
    encryptor.encrypt_file(str(original_file), str(encrypted_file), password)
    print_success(f"File encrypted: {encrypted_file}")
    
    # Show encrypted content
    encrypted_bytes = encrypted_file.read_bytes()
    print_info(f"Encrypted (hex, first 64 chars): {encrypted_bytes[:32].hex()}")
    print_info(f"File size: Original={original_file.stat().st_size}B, Encrypted={encrypted_file.stat().st_size}B")
    
    print_step(4, "Decrypt file")
    decrypted_file = test_dir / "confidential_report_decrypted.txt"
    encryptor.decrypt_file(str(encrypted_file), str(decrypted_file), password)
    print_success(f"File decrypted: {decrypted_file}")
    
    # Verify content
    decrypted_content = decrypted_file.read_text()
    print_info(f"Content matches original: {decrypted_content == original_content}")
    
    print_step(5, "Test wrong password protection")
    try:
        wrong_decrypt = test_dir / "wrong.txt"
        encryptor.decrypt_file(str(encrypted_file), str(wrong_decrypt), "WrongPassword")
        print(f"{Fore.RED}   ✗ Should have failed!")
    except Exception as e:
        print_success(f"Correctly rejected wrong password")
        print_info(f"Error: {str(e)[:60]}...")
    
    # Cleanup
    original_file.unlink()
    encrypted_file.unlink()
    decrypted_file.unlink()


def demo_rsa_and_signatures():
    """Demonstrate RSA and digital signatures"""
    print_header("DEMO 2: RSA-2048 & DIGITAL SIGNATURES")
    
    print_step(1, "Generate RSA-2048 key pair")
    key_mgr = RSAKeyManager()
    key_mgr.generate_keys(2048)
    print_success("RSA-2048 keys generated")
    print_info("Private key: Used for signing and decryption")
    print_info("Public key: Used for verification and encryption")
    
    print_step(2, "Test RSA encryption/decryption")
    secret_message = b"Secret encryption key: AES-256-XYZ123"
    print_info(f"Original message: {secret_message.decode()}")
    
    encrypted_msg = key_mgr.encrypt_with_public_key(secret_message)
    print_success(f"Encrypted with public key (first 32 bytes): {encrypted_msg[:32].hex()}")
    
    decrypted_msg = key_mgr.decrypt_with_private_key(encrypted_msg)
    print_success(f"Decrypted with private key: {decrypted_msg.decode()}")
    
    print_step(3, "Create and verify digital signature")
    test_dir = Path("/tmp/cryptbox_demo")
    test_dir.mkdir(exist_ok=True)
    
    document = test_dir / "contract.txt"
    document.write_text("Software License Agreement - Version 2.0")
    print_info(f"Document: {document.name}")
    
    sig_mgr = DigitalSignature(key_mgr)
    signature = sig_mgr.sign_file(str(document))
    print_success(f"Digital signature created (first 40 chars): {signature[:40]}...")
    
    is_valid = sig_mgr.verify_file(str(document))
    print_success(f"Signature verification: {is_valid}")
    
    print_step(4, "Test tampering detection")
    document.write_text("Software License Agreement - Version 2.0 [TAMPERED]")
    is_valid_tampered = sig_mgr.verify_file(str(document))
    print_success(f"Tampered document detected: Signature valid = {is_valid_tampered}")
    
    # Cleanup
    document.unlink()
    (document.parent / f"{document.name}.sig").unlink()
    test_dir.rmdir()


def demo_metadata_encryption():
    """Demonstrate metadata encryption"""
    print_header("DEMO 3: METADATA ENCRYPTION (SHA-256)")
    
    print_step(1, "Initialize Metadata Manager")
    master_password = "MasterPassword123"
    meta_mgr = MetadataManager(master_password)
    print_success("Metadata Manager initialized with SHA-256")
    
    print_step(2, "Create file metadata")
    metadata = meta_mgr.create_metadata(
        original_filename="salary_data_2024.xlsx",
        file_path="/tmp/test",
        custom_attrs={
            "department": "HR",
            "confidential": True,
            "year": 2024
        }
    )
    print_info(f"Original filename: {metadata['original_filename']}")
    print_info(f"MIME type: {metadata['mime_type']}")
    print_info(f"Custom attributes: {metadata.get('custom')}")
    
    print_step(3, "Encrypt metadata")
    encrypted_meta = meta_mgr.encrypt_metadata(metadata)
    print_success(f"Metadata encrypted (first 60 chars): {encrypted_meta[:60]}...")
    print_info(f"Length: {len(encrypted_meta)} characters")
    
    print_step(4, "Decrypt metadata")
    decrypted_meta = meta_mgr.decrypt_metadata(encrypted_meta)
    print_success(f"Filename recovered: {decrypted_meta['original_filename']}")
    print_success(f"MIME type recovered: {decrypted_meta['mime_type']}")
    print_success(f"Custom data recovered: {decrypted_meta.get('custom')}")


def demo_secure_sharing():
    """Demonstrate secure file sharing"""
    print_header("DEMO 4: SECURE FILE SHARING (RSA Key Exchange)")
    
    print_step(1, "Setup: Alice wants to share a file with Bob")
    
    # Alice's setup
    print_info("Creating Alice's keys...")
    alice_key = RSAKeyManager()
    alice_key.generate_keys()
    alice_config = ConfigManager("/tmp/alice_demo_config.json")
    alice_config.set_default_password("alice_pass")
    alice_sharing = SecureSharing(alice_key, alice_config)
    print_success("Alice initialized")
    
    # Bob's setup
    print_info("Creating Bob's keys...")
    bob_key = RSAKeyManager()
    bob_key.generate_keys()
    bob_config = ConfigManager("/tmp/bob_demo_config.json")
    bob_sharing = SecureSharing(bob_key, bob_config)
    print_success("Bob initialized")
    
    print_step(2, "Alice and Bob exchange public keys")
    KeyExchange.export_public_key(
        alice_key, "/tmp/alice_public.json",
        {"name": "Alice", "email": "alice@company.com"}
    )
    KeyExchange.export_public_key(
        bob_key, "/tmp/bob_public.json",
        {"name": "Bob", "email": "bob@company.com"}
    )
    print_success("Public keys exported")
    
    print_step(3, "Alice creates sharing bundle for confidential file")
    file_path = "/encrypted/project_phoenix_specs.pdf"
    file_password = "ProjectPhoenixSecret2024"
    alice_config.set_file_password(file_path, file_password)
    
    bob_pub_key, bob_info = KeyExchange.import_public_key("/tmp/bob_public.json")
    print_info(f"Sharing with: {bob_info.get('name')} ({bob_info.get('email')})")
    
    bundle = alice_sharing.create_sharing_bundle(
        file_path, file_password, [bob_pub_key]
    )
    alice_sharing.save_sharing_bundle(bundle, "/tmp/sharing_bundle.json")
    print_success("Sharing bundle created and saved")
    print_info("Bundle contains: RSA-encrypted password for Bob")
    
    print_step(4, "Bob receives and decrypts the sharing bundle")
    success = bob_sharing.receive_shared_file(
        "/tmp/sharing_bundle.json",
        file_path
    )
    
    bob_password = bob_config.get_file_password(file_path)
    print_success(f"Bob received file access")
    print_info(f"Alice's password: {file_password}")
    print_info(f"Bob's decrypted password: {bob_password}")
    print_success(f"Passwords match: {file_password == bob_password}")
    
    # Cleanup
    import os
    for f in ["/tmp/alice_demo_config.json", "/tmp/bob_demo_config.json",
              "/tmp/alice_public.json", "/tmp/bob_public.json",
              "/tmp/sharing_bundle.json"]:
        try:
            os.remove(f)
        except:
            pass


def demo_file_manager():
    """Demonstrate automatic file manager operations"""
    print_header("DEMO 5: FILE MANAGER (Transparent Encryption)")
    
    print_step(1, "Initialize File Manager")
    key_mgr = RSAKeyManager()
    key_mgr.generate_keys()
    
    encryptor = FileEncryptor()
    sig_mgr = DigitalSignature(key_mgr)
    file_mgr = DecryptedFileManager(encryptor, sig_mgr)
    print_success("File Manager initialized")
    
    print_step(2, "Create encrypted file")
    test_dir = Path("/tmp/cryptbox_demo")
    test_dir.mkdir(exist_ok=True)
    
    encrypted_file = test_dir / "document.enc"
    password = "FilePassword123"
    
    # Create initial content
    temp_plain = test_dir / "temp.txt"
    temp_plain.write_text("Initial content")
    encryptor.encrypt_file(str(temp_plain), str(encrypted_file), password)
    temp_plain.unlink()
    print_success(f"Encrypted file created: {encrypted_file.name}")
    
    print_step(3, "Open file (automatically decrypts to temp)")
    open_file = file_mgr.open(str(encrypted_file), password)
    print_success("File opened - decrypted to temporary location")
    print_info(f"User sees: Plaintext in memory")
    print_info(f"Cloud sees: Encrypted file on disk")
    
    print_step(4, "Read decrypted content")
    content = open_file.read(0, open_file.get_size())
    print_info(f"Content: {content.decode()}")
    
    print_step(5, "Modify content")
    new_content = b"Modified content - updated data!"
    open_file.write(new_content, 0)
    open_file.truncate(len(new_content))
    print_success("Content modified in memory")
    
    print_step(6, "Close file (automatically re-encrypts)")
    file_mgr.close(str(encrypted_file))
    print_success("File closed - encrypted and saved")
    print_info("Changes automatically encrypted and synced to cloud")
    
    print_step(7, "Verify persistence")
    open_file2 = file_mgr.open(str(encrypted_file), password)
    verified = open_file2.read(0, open_file2.get_size())
    file_mgr.close(str(encrypted_file))
    print_success(f"Content persisted: {verified.decode()}")
    
    # Cleanup
    encrypted_file.unlink()
    test_dir.rmdir()


def demo_security_comparison():
    """Show security improvements over original Cryptbox"""
    print_header("DEMO 6: SECURITY IMPROVEMENTS vs ORIGINAL")
    
    print(f"{Fore.CYAN}{'Feature':<30} {'Original':<20} {'Cryptbox 2.0':<20}")
    print(f"{Fore.CYAN}{'-'*70}")
    
    improvements = [
        ("Key Derivation", "MD5", "PBKDF2-SHA256 ✓"),
        ("File Encryption", "AES-CBC", "AES-256-GCM ✓"),
        ("Authentication", "None", "Built-in (GCM) ✓"),
        ("Metadata", "Plaintext", "Encrypted ✓"),
        ("Digital Signatures", "None", "RSA-PSS ✓"),
        ("Directory Support", "No", "Yes ✓"),
        ("Secure Sharing", "Manual", "Automated ✓"),
        ("Tampering Detection", "No", "Yes ✓"),
    ]
    
    for feature, original, improved in improvements:
        if "✓" in improved:
            print(f"{Fore.WHITE}{feature:<30} {Fore.YELLOW}{original:<20} {Fore.GREEN}{improved:<20}")
        else:
            print(f"{Fore.WHITE}{feature:<30} {original:<20} {improved:<20}")
    
    print(f"\n{Fore.GREEN}Security Score:")
    print(f"{Fore.GREEN}  Original Cryptbox: 3/8 features")
    print(f"{Fore.GREEN}  Cryptbox 2.0:      8/8 features ✓")


def main():
    """Run complete demonstration"""
    print(f"\n{Fore.CYAN}{'='*70}")
    print(f"{Fore.CYAN}{'CRYPTBOX 2.0 - COMPLETE DEMONSTRATION'.center(70)}")
    print(f"{Fore.CYAN}{'Encrypted File System for Secure Cloud Storage'.center(70)}")
    print(f"{Fore.CYAN}{'='*70}\n")
    
    print(f"{Fore.YELLOW}This demonstration shows all key features without requiring")
    print(f"{Fore.YELLOW}FUSE filesystem mounting - perfect for academic presentations!\n")
    
    input(f"{Fore.WHITE}Press Enter to start demonstration...")
    
    try:
        demo_encryption_basics()
        input(f"\n{Fore.WHITE}Press Enter to continue to next demo...")
        
        demo_rsa_and_signatures()
        input(f"\n{Fore.WHITE}Press Enter to continue to next demo...")
        
        demo_metadata_encryption()
        input(f"\n{Fore.WHITE}Press Enter to continue to next demo...")
        
        demo_secure_sharing()
        input(f"\n{Fore.WHITE}Press Enter to continue to next demo...")
        
        demo_file_manager()
        input(f"\n{Fore.WHITE}Press Enter to see security comparison...")
        
        demo_security_comparison()
        
        print(f"\n{Fore.GREEN}{'='*70}")
        print(f"{Fore.GREEN}{'🎉 DEMONSTRATION COMPLETE! 🎉'.center(70)}")
        print(f"{Fore.GREEN}{'='*70}\n")
        
        print(f"{Fore.CYAN}Summary:")
        print(f"{Fore.WHITE}  ✓ AES-256-GCM authenticated encryption")
        print(f"{Fore.WHITE}  ✓ RSA-2048 key management")
        print(f"{Fore.WHITE}  ✓ PBKDF2-SHA256 key derivation")
        print(f"{Fore.WHITE}  ✓ Digital signatures for integrity")
        print(f"{Fore.WHITE}  ✓ Metadata encryption for privacy")
        print(f"{Fore.WHITE}  ✓ Secure password sharing protocol")
        print(f"{Fore.WHITE}  ✓ Transparent file encryption/decryption")
        print(f"{Fore.WHITE}  ✓ Protection against tampering and unauthorized access\n")
        
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}Demonstration interrupted.")
    except Exception as e:
        print(f"\n\n{Fore.RED}Error during demonstration: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()