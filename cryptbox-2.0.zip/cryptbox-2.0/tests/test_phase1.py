"""
Phase 1 Integration Tests
Tests all core cryptography components together
"""

import os
import sys
import shutil

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cryptbox.encryption import AESEncryption, EncryptionError, DecryptionError
from cryptbox.key_manager import RSAKeyManager, KeyManagerError
from cryptbox.signature import DigitalSignature, SignatureError
from utils.crypto_utils import CryptoUtils


def test_crypto_utils():
    """Test cryptographic utilities"""
    print("\n" + "="*60)
    print("TEST 1: Cryptographic Utilities")
    print("="*60)
    
    crypto = CryptoUtils()
    
    # Test salt generation
    salt = crypto.generate_salt()
    assert len(salt) == 32, "Salt should be 32 bytes"
    print("✓ Salt generation")
    
    # Test key derivation
    password = "test_password"
    key = crypto.derive_key_pbkdf2(password, salt)
    assert len(key) == 32, "Key should be 32 bytes"
    print("✓ PBKDF2 key derivation")
    
    # Test hashing
    data = b"test data"
    hash_result = crypto.hash_sha256_hex(data)
    assert len(hash_result) == 64, "SHA-256 hex should be 64 chars"
    print("✓ SHA-256 hashing")
    
    # Test IV generation
    iv = crypto.generate_iv()
    assert len(iv) == 16, "IV should be 16 bytes"
    print("✓ IV generation")
    
    print("✅ All crypto utility tests passed!")
    return True


def test_aes_encryption():
    """Test AES-256-GCM encryption"""
    print("\n" + "="*60)
    print("TEST 2: AES-256-GCM Encryption")
    print("="*60)
    
    aes = AESEncryption()
    
    # Test basic encryption/decryption
    plaintext = b"Cryptbox 2.0 - Secure File System"
    password = "super_secure_password"
    
    encrypted = aes.encrypt_data(plaintext, password)
    print(f"✓ Encrypted data: {len(encrypted)} bytes")
    
    decrypted = aes.decrypt_data(encrypted, password)
    assert decrypted == plaintext, "Decrypted data mismatch"
    print("✓ Decryption successful")
    
    # Test wrong password
    try:
        aes.decrypt_data(encrypted, "wrong_password")
        print("✗ FAILED: Should reject wrong password")
        return False
    except DecryptionError:
        print("✓ Wrong password rejected")
    
    # Test with AAD
    metadata = b"sensitive_file.txt"
    encrypted_aad = aes.encrypt_data(plaintext, password, metadata)
    decrypted_aad = aes.decrypt_data(encrypted_aad, password, metadata)
    assert decrypted_aad == plaintext
    print("✓ AAD encryption/decryption")
    
    # Test AAD tampering
    try:
        aes.decrypt_data(encrypted_aad, password, b"wrong_metadata")
        print("✗ FAILED: Should detect AAD tampering")
        return False
    except DecryptionError:
        print("✓ AAD tampering detected")
    
    # Test file encryption
    test_file = "/tmp/cryptbox_test_enc.txt"
    enc_file = "/tmp/cryptbox_test_enc.enc"
    dec_file = "/tmp/cryptbox_test_dec.txt"
    
    with open(test_file, 'w') as f:
        f.write("Test file content for encryption")
    
    aes.encrypt_file(test_file, enc_file, password)
    print("✓ File encryption")
    
    aes.decrypt_file(enc_file, dec_file, password)
    print("✓ File decryption")
    
    # Verify content
    with open(test_file, 'r') as f1, open(dec_file, 'r') as f2:
        assert f1.read() == f2.read()
    print("✓ File content verified")
    
    # Cleanup
    os.remove(test_file)
    os.remove(enc_file)
    os.remove(dec_file)
    
    print("✅ All AES encryption tests passed!")
    return True


def test_rsa_key_management():
    """Test RSA key management"""
    print("\n" + "="*60)
    print("TEST 3: RSA Key Management")
    print("="*60)
    
    test_key_dir = "/tmp/cryptbox_test_keys"
    
    # Test key generation
    key_mgr = RSAKeyManager(test_key_dir)
    private_pem, public_pem = key_mgr.generate_key_pair(save=True)
    print("✓ RSA key pair generated")
    
    # Test key loading
    key_mgr2 = RSAKeyManager(test_key_dir)
    assert key_mgr2.load_keys()
    print("✓ Keys loaded from disk")
    
    # Test encryption/decryption
    test_password = "file_password_123"
    encrypted_pwd = key_mgr.encrypt_with_public_key(test_password.encode())
    print("✓ Password encrypted with RSA")
    
    decrypted_pwd = key_mgr.decrypt_with_private_key(encrypted_pwd)
    assert decrypted_pwd.decode() == test_password
    print("✓ Password decrypted with RSA")
    
    # Test multi-user encryption
    key_mgr_user2 = RSAKeyManager("/tmp/cryptbox_test_keys2")
    key_mgr_user2.generate_key_pair(save=True)
    
    public_keys = [
        key_mgr.get_public_key_pem(),
        key_mgr_user2.get_public_key_pem()
    ]
    
    shared_pwd = "shared_secret"
    encrypted_pwds = key_mgr.encrypt_password_for_users(shared_pwd, public_keys)
    print(f"✓ Password encrypted for {len(encrypted_pwds)} users")
    
    # Both users decrypt
    pwd1 = key_mgr.decrypt_password_for_user(encrypted_pwds)
    pwd2 = key_mgr_user2.decrypt_password_for_user(encrypted_pwds)
    assert pwd1 == pwd2 == shared_pwd
    print("✓ Multi-user decryption successful")
    
    # Cleanup
    shutil.rmtree(test_key_dir, ignore_errors=True)
    shutil.rmtree("/tmp/cryptbox_test_keys2", ignore_errors=True)
    
    print("✅ All RSA key management tests passed!")
    return True


def test_digital_signatures():
    """Test digital signatures"""
    print("\n" + "="*60)
    print("TEST 4: Digital Signatures")
    print("="*60)
    
    test_key_dir = "/tmp/cryptbox_test_sig"
    
    # Setup keys
    key_mgr = RSAKeyManager(test_key_dir)
    key_mgr.generate_key_pair(save=True)
    
    sig_handler = DigitalSignature(key_mgr)
    
    # Test data signing
    test_data = b"Important document that needs signing"
    signature = sig_handler.sign_data(test_data)
    print("✓ Data signed")
    
    # Test verification
    is_valid = sig_handler.verify_signature(test_data, signature)
    assert is_valid
    print("✓ Signature verified")
    
    # Test tampered data
    tampered = b"Modified document"
    is_valid_tampered = sig_handler.verify_signature(tampered, signature)
    assert not is_valid_tampered
    print("✓ Tampered data detected")
    
    # Test file signing
    test_file = "/tmp/test_doc.txt"
    with open(test_file, 'w') as f:
        f.write("Document content for signing")
    
    sig_package = sig_handler.sign_file(test_file)
    print("✓ File signed with metadata")
    
    # Test file verification
    is_valid, message = sig_handler.verify_file(test_file, sig_package)
    assert is_valid
    print(f"✓ File verified: {message}")
    
    # Test modified file detection
    with open(test_file, 'a') as f:
        f.write(" TAMPERED")
    
    is_valid_mod, msg_mod = sig_handler.verify_file(test_file, sig_package)
    assert not is_valid_mod
    print(f"✓ File modification detected: {msg_mod}")
    
    # Cleanup
    os.remove(test_file)
    shutil.rmtree(test_key_dir, ignore_errors=True)
    
    print("✅ All digital signature tests passed!")
    return True


def test_integrated_workflow():
    """Test complete encryption workflow with signatures"""
    print("\n" + "="*60)
    print("TEST 5: Integrated Workflow")
    print("="*60)
    
    test_key_dir = "/tmp/cryptbox_integrated_test"
    
    # Setup
    key_mgr = RSAKeyManager(test_key_dir)
    key_mgr.generate_key_pair(save=True)
    
    aes = AESEncryption()
    sig_handler = DigitalSignature(key_mgr)
    
    # Create test file
    test_file = "/tmp/integrated_test.txt"
    with open(test_file, 'w') as f:
        f.write("Secret data that needs encryption and signing")
    
    # Step 1: Encrypt file
    enc_file = "/tmp/integrated_test.enc"
    file_password = "file_password_123"
    
    with open(test_file, 'rb') as f:
        plaintext = f.read()
    
    encrypted = aes.encrypt_data(plaintext, file_password)
    
    with open(enc_file, 'wb') as f:
        f.write(encrypted)
    
    print("✓ File encrypted")
    
    # Step 2: Sign encrypted file
    signature = sig_handler.sign_encrypted_file(encrypted)
    print("✓ Encrypted file signed")
    
    # Step 3: Verify signature
    is_valid = sig_handler.verify_encrypted_file(encrypted, signature)
    assert is_valid
    print("✓ Signature verified")
    
    # Step 4: Decrypt file
    decrypted = aes.decrypt_data(encrypted, file_password)
    assert decrypted == plaintext
    print("✓ File decrypted successfully")
    
    # Step 5: Test tampering
    tampered_encrypted = encrypted[:-10] + b"TAMPERED!!"
    is_valid_tampered = sig_handler.verify_encrypted_file(
        tampered_encrypted, 
        signature
    )
    assert not is_valid_tampered
    print("✓ File tampering detected via signature")
    
    # Cleanup
    os.remove(test_file)
    os.remove(enc_file)
    shutil.rmtree(test_key_dir, ignore_errors=True)
    
    print("✅ Integrated workflow test passed!")
    return True


def run_all_tests():
    """Run all Phase 1 tests"""
    print("\n" + "🔐"*30)
    print("CRYPTBOX 2.0 - PHASE 1 CORE CRYPTOGRAPHY TESTS")
    print("🔐"*30)
    
    tests = [
        ("Crypto Utils", test_crypto_utils),
        ("AES Encryption", test_aes_encryption),
        ("RSA Key Management", test_rsa_key_management),
        ("Digital Signatures", test_digital_signatures),
        ("Integrated Workflow", test_integrated_workflow),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"\n❌ {test_name} FAILED: {str(e)}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\n{passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL PHASE 1 TESTS PASSED! 🎉")
        print("\nPhase 1 (Core Cryptography) is complete!")
        print("Ready to move to Phase 2 (File System Implementation)")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please review.")
    
    return passed == total


if __name__ == "__main__":
    run_all_tests()