#!/usr/bin/env python3
"""
Cryptbox 2.0 - Phase 2 Testing

Tests all Phase 2 components:
- Metadata encryption
- Configuration management
- File manager
- Filesystem (basic tests without mounting)
"""

import os
import sys
import json
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from cryptbox.metadata import MetadataManager, DirectoryMetadataManager
from cryptbox.config_manager import ConfigManager
from cryptbox.file_manager import DecryptedFileManager, OpenDecryptedFile
from cryptbox.encryption import FileEncryptor
from cryptbox.signature import DigitalSignature
from cryptbox.key_manager import RSAKeyManager


def test_metadata():
    """Test metadata encryption."""
    print("\n" + "="*60)
    print("TEST 1: METADATA ENCRYPTION")
    print("="*60)
    
    try:
        master_password = "test_master_password"
        meta_mgr = MetadataManager(master_password)
        
        # Create metadata
        print("\n1. Creating metadata...")
        metadata = meta_mgr.create_metadata(
            original_filename="document.pdf",
            file_path="/tmp/test.pdf",
            custom_attrs={"confidential": True}
        )
        print(f"   ✓ Metadata created: {metadata['original_filename']}")
        
        # Encrypt metadata
        print("\n2. Encrypting metadata...")
        encrypted = meta_mgr.encrypt_metadata(metadata)
        print(f"   ✓ Encrypted (first 50 chars): {encrypted[:50]}...")
        
        # Decrypt metadata
        print("\n3. Decrypting metadata...")
        decrypted = meta_mgr.decrypt_metadata(encrypted)
        print(f"   ✓ Decrypted filename: {decrypted['original_filename']}")
        
        # Verify
        assert decrypted['original_filename'] == "document.pdf"
        assert decrypted['mime_type'] == "application/pdf"
        
        print("\n✅ Metadata encryption: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ Metadata encryption: FAILED - {e}")
        return False


def test_config_manager():
    """Test configuration management."""
    print("\n" + "="*60)
    print("TEST 2: CONFIGURATION MANAGER")
    print("="*60)
    
    try:
        # Create temp config
        temp_config = "/tmp/cryptbox_test_config.json"
        config_mgr = ConfigManager(temp_config)
        
        # Set default password
        print("\n1. Setting default password...")
        config_mgr.set_default_password("my_default_password")
        print(f"   ✓ Default password set")
        
        # Set file-specific password
        print("\n2. Setting file-specific password...")
        config_mgr.set_file_password("/test/secret.txt", "secret_password")
        print(f"   ✓ File password set")
        
        # Get passwords
        print("\n3. Retrieving passwords...")
        default_pwd = config_mgr.get_default_password()
        file_pwd = config_mgr.get_file_password("/test/secret.txt")
        print(f"   ✓ Default: {default_pwd}")
        print(f"   ✓ File-specific: {file_pwd}")
        
        # Set preferences
        print("\n4. Setting preferences...")
        config_mgr.set_preference("auto_mount", True)
        auto_mount = config_mgr.get_preference("auto_mount")
        print(f"   ✓ Auto-mount: {auto_mount}")
        
        # Verify
        assert default_pwd == "my_default_password"
        assert file_pwd == "secret_password"
        assert auto_mount == True
        
        # Cleanup
        os.remove(temp_config)
        
        print("\n✅ Configuration manager: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ Configuration manager: FAILED - {e}")
        return False


def test_file_manager():
    """Test file manager."""
    print("\n" + "="*60)
    print("TEST 3: FILE MANAGER")
    print("="*60)
    
    try:
        # Setup
        test_dir = Path("/tmp/cryptbox_file_manager_test")
        test_dir.mkdir(exist_ok=True)
        
        password = "test_password"
        encrypted_file = test_dir / "test.enc"
        
        # Initialize
        print("\n1. Initializing file manager...")
        key_mgr = RSAKeyManager()
        key_mgr.generate_keys()
        
        file_encryptor = FileEncryptor()
        signature_mgr = DigitalSignature(key_mgr)
        file_mgr = DecryptedFileManager(file_encryptor, signature_mgr)
        print(f"   ✓ File manager initialized")
        
        # Create test file
        print("\n2. Creating encrypted test file...")
        test_content = b"This is secret test data!"
        temp_file = test_dir / "plain.txt"
        temp_file.write_bytes(test_content)
        file_encryptor.encrypt_file(str(temp_file), str(encrypted_file), password)
        print(f"   ✓ Encrypted file created")
        
        # Open file
        print("\n3. Opening encrypted file...")
        open_file = file_mgr.open(str(encrypted_file), password)
        print(f"   ✓ File opened, size: {open_file.get_size()} bytes")
        
        # Read content
        print("\n4. Reading decrypted content...")
        content = open_file.read(0, open_file.get_size())
        print(f"   ✓ Content: {content.decode()}")
        
        # Write new content
        print("\n5. Writing new content...")
        new_content = b"Updated secret data!"
        open_file.write(new_content, 0)
        open_file.truncate(len(new_content))
        print(f"   ✓ New content written")
        
        # Close file
        print("\n6. Closing file (auto-encrypt)...")
        file_mgr.close(str(encrypted_file))
        print(f"   ✓ File closed and re-encrypted")
        
        # Verify persistence
        print("\n7. Re-opening to verify...")
        open_file2 = file_mgr.open(str(encrypted_file), password)
        verified = open_file2.read(0, open_file2.get_size())
        print(f"   ✓ Verified: {verified.decode()}")
        file_mgr.close(str(encrypted_file))
        
        # Verify
        assert verified == new_content
        
        # Cleanup
        temp_file.unlink(missing_ok=True)
        encrypted_file.unlink(missing_ok=True)
        test_dir.rmdir()
        
        print("\n✅ File manager: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ File manager: FAILED - {e}")
        import traceback
        traceback.print_exc()
        return False


def test_directory_metadata():
    """Test directory metadata."""
    print("\n" + "="*60)
    print("TEST 4: DIRECTORY METADATA")
    print("="*60)
    
    try:
        master_password = "test_master_password"
        dir_mgr = DirectoryMetadataManager(master_password)
        
        # Create directory metadata
        print("\n1. Creating directory metadata...")
        dir_meta = dir_mgr.create_directory_metadata("my_folder", "/home/user")
        print(f"   ✓ Directory metadata created: {dir_meta['name']}")
        
        # Encrypt
        print("\n2. Encrypting directory metadata...")
        encrypted = dir_mgr.encrypt_directory_metadata(dir_meta)
        print(f"   ✓ Encrypted")
        
        # Add children
        print("\n3. Adding children...")
        encrypted = dir_mgr.add_child(encrypted, "file1.txt")
        encrypted = dir_mgr.add_child(encrypted, "file2.pdf")
        print(f"   ✓ Children added")
        
        # Decrypt and verify
        print("\n4. Verifying...")
        decrypted = dir_mgr.decrypt_directory_metadata(encrypted)
        print(f"   ✓ Children: {decrypted['children']}")
        
        # Verify
        assert "file1.txt" in decrypted['children']
        assert "file2.pdf" in decrypted['children']
        
        print("\n✅ Directory metadata: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ Directory metadata: FAILED - {e}")
        return False


def run_all_tests():
    """Run all Phase 2 tests."""
    print("\n" + "="*60)
    print("CRYPTBOX 2.0 - PHASE 2 TEST SUITE")
    print("="*60)
    
    results = []
    
    # Run tests
    results.append(("Metadata Encryption", test_metadata()))
    results.append(("Config Manager", test_config_manager()))
    results.append(("File Manager", test_file_manager()))
    results.append(("Directory Metadata", test_directory_metadata()))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{name:.<40} {status}")
    
    print("\n" + "="*60)
    print(f"Results: {passed}/{total} tests passed")
    print("="*60)
    
    return passed == total


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)