#!/usr/bin/env python3
"""
Cryptbox 2.0 - Phase 3 Integration Tests

Tests Phase 3 components:
- Secure sharing
- Complete encryption/decryption workflow
- Integration of all components
"""



import os
import sys
import json
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from cryptbox.key_manager import RSAKeyManager
from cryptbox.config_manager import ConfigManager
from cryptbox.encryption import FileEncryptor
from cryptbox.file_manager import DecryptedFileManager
from cryptbox.signature import DigitalSignature
from cryptbox.sharing import SecureSharing, KeyExchange


def test_secure_sharing():
    """Test secure file sharing between users."""
    print("\n" + "="*60)
    print("TEST 1: SECURE SHARING")
    print("="*60)
    
    try:
        # Setup Alice
        print("\n1. Setting up Alice (sender)...")
        alice_key_mgr = RSAKeyManager()
        alice_key_mgr.generate_keys()
        alice_config = ConfigManager("/tmp/test_alice_config.json")
        alice_config.set_default_password("alice_password")
        alice_sharing = SecureSharing(alice_key_mgr, alice_config)
        print("   ✓ Alice initialized")
        
        # Setup Bob
        print("\n2. Setting up Bob (receiver)...")
        bob_key_mgr = RSAKeyManager()
        bob_key_mgr.generate_keys()
        bob_config = ConfigManager("/tmp/test_bob_config.json")
        bob_config.set_default_password("bob_password")
        bob_sharing = SecureSharing(bob_key_mgr, bob_config)
        print("   ✓ Bob initialized")
        
        # Export public keys
        print("\n3. Exchanging public keys...")
        KeyExchange.export_public_key(
            alice_key_mgr,
            "/tmp/alice_pub.json",
            {"name": "Alice"}
        )
        KeyExchange.export_public_key(
            bob_key_mgr,
            "/tmp/bob_pub.json",
            {"name": "Bob"}
        )
        print("   ✓ Public keys exported")
        
        # Alice shares a file
        print("\n4. Alice creates sharing bundle...")
        file_path = "/test/shared_file.txt"
        file_password = "shared_secret_123"
        alice_config.set_file_password(file_path, file_password)
        
        bob_pub_key, _ = KeyExchange.import_public_key("/tmp/bob_pub.json")
        bundle = alice_sharing.create_sharing_bundle(
            file_path,
            file_password,
            [bob_pub_key]
        )
        alice_sharing.save_sharing_bundle(bundle, "/tmp/share_bundle.json")
        print("   ✓ Sharing bundle created")
        
        # Bob receives the file
        print("\n5. Bob receives shared file...")
        success = bob_sharing.receive_shared_file(
            "/tmp/share_bundle.json",
            file_path
        )
        print(f"   ✓ Receive status: {success}")
        
        # Verify passwords match
        print("\n6. Verifying password transfer...")
        bob_password = bob_config.get_file_password(file_path)
        print(f"   Alice's password: {file_password}")
        print(f"   Bob's password:   {bob_password}")
        print(f"   Match: {file_password == bob_password}")
        
        # Verify
        assert success == True
        assert bob_password == file_password
        
        # Cleanup
        for f in ["/tmp/test_alice_config.json", "/tmp/test_bob_config.json",
                  "/tmp/alice_pub.json", "/tmp/bob_pub.json", 
                  "/tmp/share_bundle.json"]:
            try:
                os.remove(f)
            except:
                pass
        
        print("\n✅ Secure sharing: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ Secure sharing: FAILED - {e}")
        import traceback
        traceback.print_exc()
        return False


def test_end_to_end_workflow():
    """Test complete encryption/decryption workflow."""
    print("\n" + "="*60)
    print("TEST 2: END-TO-END WORKFLOW")
    print("="*60)
    
    try:
        # Setup
        print("\n1. Setting up test environment...")
        test_dir = Path("/tmp/cryptbox_e2e_test")
        test_dir.mkdir(exist_ok=True)
        
        # Initialize all components
        key_mgr = RSAKeyManager()
        key_mgr.generate_keys()
        
        config = ConfigManager("/tmp/test_e2e_config.json")
        config.set_default_password("test_password_123")
        
        encryptor = FileEncryptor()
        signature_mgr = DigitalSignature(key_mgr)
        file_mgr = DecryptedFileManager(encryptor, signature_mgr)
        
        print("   ✓ All components initialized")
        
        # Create original file
        print("\n2. Creating original file...")
        original_content = b"This is secret data for end-to-end test!"
        plain_file = test_dir / "original.txt"
        plain_file.write_bytes(original_content)
        print(f"   ✓ Original content: {original_content.decode()}")
        
        # Encrypt file
        print("\n3. Encrypting file...")
        encrypted_file = test_dir / "encrypted.enc"
        password = config.get_default_password()
        encryptor.encrypt_file(str(plain_file), str(encrypted_file), password)
        print("   ✓ File encrypted")
        
        # Sign file
        print("\n4. Signing encrypted file...")
        signature = signature_mgr.sign_file(str(encrypted_file))
        print(f"   ✓ Signature created (first 32 chars): {signature[:32]}...")
        
        # Open through file manager
        print("\n5. Opening through file manager...")
        open_file = file_mgr.open(str(encrypted_file), password)
        print(f"   ✓ File opened, size: {open_file.get_size()} bytes")
        
        # Read content
        print("\n6. Reading decrypted content...")
        decrypted_content = open_file.read(0, open_file.get_size())
        print(f"   ✓ Content: {decrypted_content.decode()}")
        
        # Modify content
        print("\n7. Modifying content...")
        new_content = b"Modified secret data!"
        open_file.write(new_content, 0)
        open_file.truncate(len(new_content))
        print(f"   ✓ New content: {new_content.decode()}")
        
        # Close (auto-encrypt and sign)
        print("\n8. Closing file (auto-encrypt)...")
        file_mgr.close(str(encrypted_file))
        print("   ✓ File closed and re-encrypted")
        
        # Verify signature
        print("\n9. Verifying signature...")
        is_valid = signature_mgr.verify_file(str(encrypted_file))
        print(f"   ✓ Signature valid: {is_valid}")
        
        # Re-open and verify persistence
        print("\n10. Re-opening to verify persistence...")
        open_file2 = file_mgr.open(str(encrypted_file), password)
        verified_content = open_file2.read(0, open_file2.get_size())
        print(f"   ✓ Verified: {verified_content.decode()}")
        file_mgr.close(str(encrypted_file))
        
        # Final verification
        assert decrypted_content == original_content
        assert verified_content == new_content
        assert is_valid == True
        
        # Cleanup
        plain_file.unlink(missing_ok=True)
        encrypted_file.unlink(missing_ok=True)
        (encrypted_file.parent / f"{encrypted_file.name}.sig").unlink(missing_ok=True)
        test_dir.rmdir()
        os.remove("/tmp/test_e2e_config.json")
        
        print("\n✅ End-to-end workflow: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ End-to-end workflow: FAILED - {e}")
        import traceback
        traceback.print_exc()
        return False


def test_multi_user_sharing():
    """Test sharing with multiple users."""
    print("\n" + "="*60)
    print("TEST 3: MULTI-USER SHARING")
    print("="*60)
    
    try:
        # Setup Alice (sender)
        print("\n1. Setting up users...")
        alice_key = RSAKeyManager()
        alice_key.generate_keys()
        alice_config = ConfigManager("/tmp/test_alice_multi.json")
        alice_config.set_default_password("alice")
        alice_sharing = SecureSharing(alice_key, alice_config)
        
        # Setup Bob (receiver 1)
        bob_key = RSAKeyManager()
        bob_key.generate_keys()
        bob_config = ConfigManager("/tmp/test_bob_multi.json")
        bob_sharing = SecureSharing(bob_key, bob_config)
        
        # Setup Charlie (receiver 2)
        charlie_key = RSAKeyManager()
        charlie_key.generate_keys()
        charlie_config = ConfigManager("/tmp/test_charlie_multi.json")
        charlie_sharing = SecureSharing(charlie_key, charlie_config)
        
        print("   ✓ Alice, Bob, and Charlie initialized")
        
        # Alice shares with both Bob and Charlie
        print("\n2. Alice sharing with Bob and Charlie...")
        file_path = "/shared/team_document.txt"
        password = "team_password_456"
        alice_config.set_file_password(file_path, password)
        
        bob_pub = bob_key.export_public_key()
        charlie_pub = charlie_key.export_public_key()
        
        bundle = alice_sharing.create_sharing_bundle(
            file_path,
            password,
            [bob_pub, charlie_pub]
        )
        alice_sharing.save_sharing_bundle(bundle, "/tmp/team_bundle.json")
        print("   ✓ Sharing bundle with 2 recipients created")
        
        # Bob receives
        print("\n3. Bob receiving...")
        bob_success = bob_sharing.receive_shared_file(
            "/tmp/team_bundle.json",
            file_path
        )
        bob_pwd = bob_config.get_file_password(file_path)
        print(f"   ✓ Bob received: {bob_success}, password: {bob_pwd}")
        
        # Charlie receives
        print("\n4. Charlie receiving...")
        charlie_success = charlie_sharing.receive_shared_file(
            "/tmp/team_bundle.json",
            file_path
        )
        charlie_pwd = charlie_config.get_file_password(file_path)
        print(f"   ✓ Charlie received: {charlie_success}, password: {charlie_pwd}")
        
        # Verify all have same password
        print("\n5. Verifying all passwords match...")
        print(f"   Alice:   {password}")
        print(f"   Bob:     {bob_pwd}")
        print(f"   Charlie: {charlie_pwd}")
        
        assert bob_success and charlie_success
        assert bob_pwd == password
        assert charlie_pwd == password
        
        # Cleanup
        for f in ["/tmp/test_alice_multi.json", "/tmp/test_bob_multi.json",
                  "/tmp/test_charlie_multi.json", "/tmp/team_bundle.json"]:
            try:
                os.remove(f)
            except:
                pass
        
        print("\n✅ Multi-user sharing: PASSED")
        return True
        
    except Exception as e:
        print(f"\n❌ Multi-user sharing: FAILED - {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """Run all Phase 3 tests."""
    print("\n" + "="*60)
    print("CRYPTBOX 2.0 - PHASE 3 INTEGRATION TEST SUITE")
    print("="*60)
    
    results = []
    
    # Run tests
    results.append(("Secure Sharing", test_secure_sharing()))
    results.append(("End-to-End Workflow", test_end_to_end_workflow()))
    results.append(("Multi-User Sharing", test_multi_user_sharing()))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{name:.<40} {status}")
    
    print("\n" + "="*60)
    print(f"Results: {passed}/{total} tests passed")
    print("="*60)
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! Cryptbox 2.0 is ready!")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please review.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)