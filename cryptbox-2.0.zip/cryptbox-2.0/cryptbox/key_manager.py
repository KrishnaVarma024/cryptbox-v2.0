"""
Cryptbox 2.0 - RSA Key Manager

Handles RSA key generation, storage, and management for:
- File encryption key protection
- Digital signatures
- Secure sharing
"""

import os
from pathlib import Path
from typing import Optional
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256


class RSAKeyManager:
    """
    Manages RSA key pairs for Cryptbox operations.
    Handles key generation, loading, saving, and basic operations.
    """
    
    def __init__(self, 
                 private_key_path: Optional[str] = None,
                 public_key_path: Optional[str] = None):
        """
        Initialize RSA Key Manager.
        
        Args:
            private_key_path: Path to save/load private key
            public_key_path: Path to save/load public key
        """
        self.private_key_path = private_key_path
        self.public_key_path = public_key_path
        self.private_key: Optional[RSA.RsaKey] = None
        self.public_key: Optional[RSA.RsaKey] = None
    
    def generate_keys(self, key_size: int = 2048):
        """
        Generate a new RSA key pair.
        
        Args:
            key_size: Size of RSA key in bits (default: 2048)
        """
        self.private_key = RSA.generate(key_size)
        self.public_key = self.private_key.publickey()
        print(f"Generated RSA-{key_size} key pair")
    
    def save_keys(self):
        """
        Save keys to files.
        Private key is saved with restrictive permissions.
        """
        if not self.private_key or not self.public_key:
            raise ValueError("No keys to save. Generate keys first.")
        
        if not self.private_key_path or not self.public_key_path:
            raise ValueError("Key paths not specified")
        
        # Create directory if it doesn't exist
        Path(self.private_key_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Save private key
        private_pem = self.private_key.export_key()
        with open(self.private_key_path, 'wb') as f:
            f.write(private_pem)
        os.chmod(self.private_key_path, 0o600)  # Read/write for owner only
        
        # Save public key
        public_pem = self.public_key.export_key()
        with open(self.public_key_path, 'wb') as f:
            f.write(public_pem)
        
        print(f"Keys saved:")
        print(f"  Private: {self.private_key_path}")
        print(f"  Public: {self.public_key_path}")
    
    def load_keys(self):
        """Load keys from files."""
        if not self.private_key_path or not self.public_key_path:
            raise ValueError("Key paths not specified")
        
        # Load private key
        with open(self.private_key_path, 'rb') as f:
            self.private_key = RSA.import_key(f.read())
        
        # Load public key
        with open(self.public_key_path, 'rb') as f:
            self.public_key = RSA.import_key(f.read())
        
        print(f"Keys loaded from:")
        print(f"  Private: {self.private_key_path}")
        print(f"  Public: {self.public_key_path}")
    
    def get_private_key(self) -> RSA.RsaKey:
        """
        Get the private key.
        
        Returns:
            RSA private key
        """
        if not self.private_key:
            raise ValueError("Private key not available")
        return self.private_key
    
    def get_public_key(self) -> RSA.RsaKey:
        """
        Get the public key.
        
        Returns:
            RSA public key
        """
        if not self.public_key:
            raise ValueError("Public key not available")
        return self.public_key
    
    def export_public_key(self) -> str:
        """
        Export public key as PEM string.
        
        Returns:
            Public key in PEM format
        """
        if not self.public_key:
            raise ValueError("Public key not available")
        return self.public_key.export_key().decode('utf-8')
    
    def import_public_key(self, pem_data: str):
        """
        Import a public key from PEM string.
        
        Args:
            pem_data: Public key in PEM format
        """
        self.public_key = RSA.import_key(pem_data)
    
    def encrypt_with_public_key(self, data: bytes) -> bytes:
        """
        Encrypt data with public key using OAEP padding.
        
        Args:
            data: Data to encrypt
            
        Returns:
            Encrypted data
        """
        if not self.public_key:
            raise ValueError("Public key not available")
        
        cipher = PKCS1_OAEP.new(self.public_key)
        return cipher.encrypt(data)
    
    def decrypt_with_private_key(self, encrypted_data: bytes) -> bytes:
        """
        Decrypt data with private key.
        
        Args:
            encrypted_data: Encrypted data
            
        Returns:
            Decrypted data
        """
        if not self.private_key:
            raise ValueError("Private key not available")
        
        cipher = PKCS1_OAEP.new(self.private_key)
        return cipher.decrypt(encrypted_data)
    
    def sign_data(self, data: bytes) -> bytes:
        """
        Sign data with private key.
        
        Args:
            data: Data to sign
            
        Returns:
            Signature bytes
        """
        if not self.private_key:
            raise ValueError("Private key not available")
        
        h = SHA256.new(data)
        signature = pkcs1_15.new(self.private_key).sign(h)
        return signature
    
    def verify_signature(self, data: bytes, signature: bytes) -> bool:
        """
        Verify signature with public key.
        
        Args:
            data: Original data
            signature: Signature to verify
            
        Returns:
            True if signature is valid
        """
        if not self.public_key:
            raise ValueError("Public key not available")
        
        h = SHA256.new(data)
        try:
            pkcs1_15.new(self.public_key).verify(h, signature)
            return True
        except (ValueError, TypeError):
            return False


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - RSA Key Manager Demo ===\n")
    
    # Generate keys
    print("1. Generating RSA key pair...")
    key_manager = RSAKeyManager()
    key_manager.generate_keys(key_size=2048)
    print()
    
    # Test encryption/decryption
    print("2. Testing public key encryption...")
    original_data = b"This is secret data!"
    print(f"   Original: {original_data.decode()}")
    
    encrypted = key_manager.encrypt_with_public_key(original_data)
    print(f"   Encrypted (first 32 bytes): {encrypted[:32].hex()}...")
    
    decrypted = key_manager.decrypt_with_private_key(encrypted)
    print(f"   Decrypted: {decrypted.decode()}")
    print(f"   Match: {original_data == decrypted}")
    print()
    
    # Test signing
    print("3. Testing digital signatures...")
    data_to_sign = b"Important message"
    print(f"   Data: {data_to_sign.decode()}")
    
    signature = key_manager.sign_data(data_to_sign)
    print(f"   Signature (first 32 bytes): {signature[:32].hex()}...")
    
    is_valid = key_manager.verify_signature(data_to_sign, signature)
    print(f"   Signature valid: {is_valid}")
    
    # Test with tampered data
    tampered_data = b"Important messag!"  # Changed last char
    is_valid_tampered = key_manager.verify_signature(tampered_data, signature)
    print(f"   Tampered data valid: {is_valid_tampered}")
    print()
    
    # Test save/load
    print("4. Testing key persistence...")
    import tempfile
    temp_dir = tempfile.mkdtemp()
    
    key_manager.private_key_path = f"{temp_dir}/private.pem"
    key_manager.public_key_path = f"{temp_dir}/public.pem"
    
    key_manager.save_keys()
    print()
    
    # Load keys
    print("5. Loading saved keys...")
    key_manager2 = RSAKeyManager(
        f"{temp_dir}/private.pem",
        f"{temp_dir}/public.pem"
    )
    key_manager2.load_keys()
    print()
    
    # Verify loaded keys work
    print("6. Verifying loaded keys...")
    encrypted2 = key_manager2.encrypt_with_public_key(original_data)
    decrypted2 = key_manager2.decrypt_with_private_key(encrypted2)
    print(f"   Encryption/decryption works: {decrypted2 == original_data}")
    
    # Cleanup
    import shutil
    shutil.rmtree(temp_dir)
    
    print("\n✅ RSA Key Manager working correctly!")