"""
Cryptbox 2.0 - Metadata Encryption Module

This module handles encryption of file metadata including:
- Original filenames
- MIME types
- File sizes
- Timestamps
- Custom attributes
"""

import json
import base64
import mimetypes
import os
from datetime import datetime
from typing import Dict, Any, Optional
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from utils.crypto_utils import derive_key


class MetadataManager:
    """
    Manages encryption and decryption of file metadata.
    Metadata is stored separately from file content for security.
    """
    
    METADATA_VERSION = "2.0"
    
    def __init__(self, master_password: str):
        """
        Initialize MetadataManager with a master password.
        
        Args:
            master_password: Master password for metadata encryption
        """
        self.master_password = master_password
        self.metadata_key = derive_key(master_password, b"metadata_salt_v2")
    
    def create_metadata(self, 
                       original_filename: str,
                       file_path: str,
                       custom_attrs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Create metadata dictionary for a file.
        
        Args:
            original_filename: Original name of the file
            file_path: Path to the file
            custom_attrs: Optional custom attributes
            
        Returns:
            Dictionary containing file metadata
        """
        mime_type, _ = mimetypes.guess_type(original_filename)
        
        metadata = {
            "version": self.METADATA_VERSION,
            "original_filename": original_filename,
            "mime_type": mime_type or "application/octet-stream",
            "created_at": datetime.now().isoformat(),
            "modified_at": datetime.now().isoformat(),
            "encrypted": True,
        }
        
        # Add file size if file exists
        if os.path.exists(file_path):
            metadata["original_size"] = os.path.getsize(file_path)
        
        # Add custom attributes
        if custom_attrs:
            metadata["custom"] = custom_attrs
        
        return metadata
    
    def encrypt_metadata(self, metadata: Dict[str, Any]) -> str:
        """
        Encrypt metadata dictionary using AES-GCM.
        
        Args:
            metadata: Metadata dictionary to encrypt
            
        Returns:
            Base64-encoded encrypted metadata string
        """
        try:
            # Convert metadata to JSON
            metadata_json = json.dumps(metadata)
            metadata_bytes = metadata_json.encode('utf-8')
            
            # Generate nonce
            nonce = get_random_bytes(12)
            
            # Create AES-GCM cipher
            cipher = AES.new(self.metadata_key, AES.MODE_GCM, nonce=nonce)
            
            # Encrypt metadata
            ciphertext, tag = cipher.encrypt_and_digest(metadata_bytes)
            
            # Combine: nonce + tag + ciphertext
            encrypted_data = nonce + tag + ciphertext
            
            # Return as base64 string
            return base64.b64encode(encrypted_data).decode('utf-8')
            
        except Exception as e:
            raise Exception(f"Failed to encrypt metadata: {str(e)}")
    
    def decrypt_metadata(self, encrypted_metadata: str) -> Dict[str, Any]:
        """
        Decrypt metadata string and return dictionary.
        
        Args:
            encrypted_metadata: Base64-encoded encrypted metadata
            
        Returns:
            Decrypted metadata dictionary
        """
        try:
            # Decode from base64
            encrypted_data = base64.b64decode(encrypted_metadata)
            
            # Extract components
            nonce = encrypted_data[:12]
            tag = encrypted_data[12:28]
            ciphertext = encrypted_data[28:]
            
            # Create AES-GCM cipher
            cipher = AES.new(self.metadata_key, AES.MODE_GCM, nonce=nonce)
            
            # Decrypt and verify
            metadata_bytes = cipher.decrypt_and_verify(ciphertext, tag)
            
            # Parse JSON
            metadata_json = metadata_bytes.decode('utf-8')
            metadata = json.loads(metadata_json)
            
            return metadata
            
        except Exception as e:
            raise Exception(f"Failed to decrypt metadata: {str(e)}")
    
    def update_metadata(self, 
                       encrypted_metadata: str,
                       updates: Dict[str, Any]) -> str:
        """
        Update existing metadata with new values.
        
        Args:
            encrypted_metadata: Existing encrypted metadata
            updates: Dictionary of updates to apply
            
        Returns:
            New encrypted metadata string
        """
        # Decrypt existing metadata
        metadata = self.decrypt_metadata(encrypted_metadata)
        
        # Update modified timestamp
        metadata["modified_at"] = datetime.now().isoformat()
        
        # Apply updates
        metadata.update(updates)
        
        # Re-encrypt and return
        return self.encrypt_metadata(metadata)
    
    def get_original_filename(self, encrypted_metadata: str) -> str:
        """
        Extract original filename from encrypted metadata.
        
        Args:
            encrypted_metadata: Encrypted metadata string
            
        Returns:
            Original filename
        """
        metadata = self.decrypt_metadata(encrypted_metadata)
        return metadata.get("original_filename", "unknown")
    
    def get_mime_type(self, encrypted_metadata: str) -> str:
        """
        Extract MIME type from encrypted metadata.
        
        Args:
            encrypted_metadata: Encrypted metadata string
            
        Returns:
            MIME type string
        """
        metadata = self.decrypt_metadata(encrypted_metadata)
        return metadata.get("mime_type", "application/octet-stream")


class DirectoryMetadataManager:
    """
    Manages metadata for encrypted directories.
    Stores directory structure information securely.
    """
    
    def __init__(self, master_password: str):
        """
        Initialize DirectoryMetadataManager.
        
        Args:
            master_password: Master password for encryption
        """
        self.master_password = master_password
        self.metadata_key = derive_key(master_password, b"dir_metadata_v2")
    
    def create_directory_metadata(self, 
                                  dir_name: str,
                                  parent_path: str = "") -> Dict[str, Any]:
        """
        Create metadata for a directory.
        
        Args:
            dir_name: Directory name
            parent_path: Parent directory path
            
        Returns:
            Directory metadata dictionary
        """
        return {
            "type": "directory",
            "name": dir_name,
            "parent": parent_path,
            "created_at": datetime.now().isoformat(),
            "modified_at": datetime.now().isoformat(),
            "children": []
        }
    
    def encrypt_directory_metadata(self, metadata: Dict[str, Any]) -> str:
        """
        Encrypt directory metadata.
        
        Args:
            metadata: Directory metadata dictionary
            
        Returns:
            Encrypted metadata string
        """
        metadata_json = json.dumps(metadata)
        metadata_bytes = metadata_json.encode('utf-8')
        
        nonce = get_random_bytes(12)
        cipher = AES.new(self.metadata_key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(metadata_bytes)
        
        encrypted_data = nonce + tag + ciphertext
        return base64.b64encode(encrypted_data).decode('utf-8')
    
    def decrypt_directory_metadata(self, encrypted_metadata: str) -> Dict[str, Any]:
        """
        Decrypt directory metadata.
        
        Args:
            encrypted_metadata: Encrypted metadata string
            
        Returns:
            Directory metadata dictionary
        """
        encrypted_data = base64.b64decode(encrypted_metadata)
        
        nonce = encrypted_data[:12]
        tag = encrypted_data[12:28]
        ciphertext = encrypted_data[28:]
        
        cipher = AES.new(self.metadata_key, AES.MODE_GCM, nonce=nonce)
        metadata_bytes = cipher.decrypt_and_verify(ciphertext, tag)
        
        metadata_json = metadata_bytes.decode('utf-8')
        return json.loads(metadata_json)
    
    def add_child(self, 
                  encrypted_metadata: str,
                  child_name: str) -> str:
        """
        Add a child to directory metadata.
        
        Args:
            encrypted_metadata: Existing encrypted directory metadata
            child_name: Name of child to add
            
        Returns:
            Updated encrypted metadata
        """
        metadata = self.decrypt_directory_metadata(encrypted_metadata)
        
        if child_name not in metadata.get("children", []):
            metadata.setdefault("children", []).append(child_name)
            metadata["modified_at"] = datetime.now().isoformat()
        
        return self.encrypt_directory_metadata(metadata)
    
    def remove_child(self,
                    encrypted_metadata: str,
                    child_name: str) -> str:
        """
        Remove a child from directory metadata.
        
        Args:
            encrypted_metadata: Existing encrypted directory metadata
            child_name: Name of child to remove
            
        Returns:
            Updated encrypted metadata
        """
        metadata = self.decrypt_directory_metadata(encrypted_metadata)
        
        if child_name in metadata.get("children", []):
            metadata["children"].remove(child_name)
            metadata["modified_at"] = datetime.now().isoformat()
        
        return self.encrypt_directory_metadata(metadata)


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - Metadata Encryption Demo ===\n")
    
    # Initialize managers
    master_password = "my_secure_master_password_123"
    
    # File Metadata
    print("1. File Metadata Encryption:")
    file_meta_mgr = MetadataManager(master_password)
    
    # Create metadata
    metadata = file_meta_mgr.create_metadata(
        original_filename="secret_document.pdf",
        file_path="/tmp/test.pdf",
        custom_attrs={"department": "Engineering", "confidential": True}
    )
    print(f"Original Metadata: {json.dumps(metadata, indent=2)}\n")
    
    # Encrypt metadata
    encrypted = file_meta_mgr.encrypt_metadata(metadata)
    print(f"Encrypted Metadata (truncated): {encrypted[:100]}...\n")
    
    # Decrypt metadata
    decrypted = file_meta_mgr.decrypt_metadata(encrypted)
    print(f"Decrypted Metadata: {json.dumps(decrypted, indent=2)}\n")
    
    # Extract specific fields
    print(f"Original Filename: {file_meta_mgr.get_original_filename(encrypted)}")
    print(f"MIME Type: {file_meta_mgr.get_mime_type(encrypted)}\n")
    
    # Directory Metadata
    print("\n2. Directory Metadata Encryption:")
    dir_meta_mgr = DirectoryMetadataManager(master_password)
    
    # Create directory metadata
    dir_metadata = dir_meta_mgr.create_directory_metadata("projects", "/home/user")
    print(f"Directory Metadata: {json.dumps(dir_metadata, indent=2)}\n")
    
    # Encrypt directory metadata
    encrypted_dir = dir_meta_mgr.encrypt_directory_metadata(dir_metadata)
    print(f"Encrypted Dir Metadata (truncated): {encrypted_dir[:100]}...\n")
    
    # Add children
    encrypted_dir = dir_meta_mgr.add_child(encrypted_dir, "project1.txt")
    encrypted_dir = dir_meta_mgr.add_child(encrypted_dir, "project2.pdf")
    
    # Decrypt and show
    decrypted_dir = dir_meta_mgr.decrypt_directory_metadata(encrypted_dir)
    print(f"Directory with Children: {json.dumps(decrypted_dir, indent=2)}\n")
    
    print("✅ Metadata encryption working correctly!")