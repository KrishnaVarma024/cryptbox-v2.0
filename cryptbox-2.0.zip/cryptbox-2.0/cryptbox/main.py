#!/usr/bin/env python3
"""
Cryptbox 2.0 - Main CLI Entry Point

Command-line interface for Cryptbox operations:
- init: Initialize Cryptbox
- mount: Mount encrypted filesystem
- unmount: Unmount filesystem
- share: Share files with other users
- receive: Receive shared files
- status: Show Cryptbox status
"""

import sys
import os
import signal
import subprocess
from pathlib import Path
from getpass import getpass
import click
from colorama import init as colorama_init, Fore, Style

from cryptbox.key_manager import RSAKeyManager
from cryptbox.config_manager import ConfigManager
from cryptbox.encryption import FileEncryptor
from cryptbox.filesystem import mount_cryptbox
from cryptbox.sharing import SecureSharing, KeyExchange

# Initialize colorama
colorama_init(autoreset=True)


class CryptboxCLI:
    """Main CLI controller for Cryptbox."""
    
    def __init__(self):
        self.config_dir = Path.home() / ".cryptbox"
        self.config_path = self.config_dir / "config.json"
        self.key_dir = self.config_dir / "keys"
        self.private_key_path = self.key_dir / "private_key.pem"
        self.public_key_path = self.key_dir / "public_key.pem"
    
    def is_initialized(self) -> bool:
        """Check if Cryptbox is initialized."""
        return (self.config_path.exists() and 
                self.private_key_path.exists() and
                self.public_key_path.exists())
    
    def print_banner(self):
        """Print Cryptbox banner."""
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.CYAN}   ╔═╗┬─┐┬ ┬┌─┐┌┬┐┌┐ ┌─┐─┐ ┬  ┌─┐  ┌─┐")
        print(f"{Fore.CYAN}   ║  ├┬┘└┬┘├─┘ │ ├┴┐│ │┌┴┬┘  ┌─┘ ┌┘ ")
        print(f"{Fore.CYAN}   ╚═╝┴└─ ┴ ┴   ┴ └─┘└─┘┴ └─  └─┘o└─┘")
        print(f"{Fore.CYAN}   Encrypted File System for Secure Cloud Storage")
        print(f"{Fore.CYAN}   Version 2.0")
        print(f"{Fore.CYAN}{'='*60}\n")


@click.group()
def cli():
    """Cryptbox 2.0 - Encrypted File System"""
    pass


@cli.command()
@click.option('--key-size', default=2048, help='RSA key size (default: 2048)')
@click.option('--mount-point', default=None, help='Custom mount point')
@click.option('--storage', default=None, help='Custom encrypted storage path')
def init(key_size, mount_point, storage):
    """Initialize Cryptbox with keys and configuration."""
    cryptbox_cli = CryptboxCLI()
    cryptbox_cli.print_banner()
    
    print(f"{Fore.YELLOW}Initializing Cryptbox...\n")
    
    # Check if already initialized
    if cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox is already initialized!")
        print(f"  Config: {cryptbox_cli.config_path}")
        print(f"  Keys: {cryptbox_cli.key_dir}")
        if not click.confirm("\nRe-initialize (will overwrite existing keys)?"):
            return
    
    # Create directories
    cryptbox_cli.config_dir.mkdir(exist_ok=True)
    cryptbox_cli.key_dir.mkdir(exist_ok=True)
    
    # Generate RSA keys
    print(f"{Fore.CYAN}1. Generating RSA keys ({key_size} bits)...")
    key_manager = RSAKeyManager(
        str(cryptbox_cli.private_key_path),
        str(cryptbox_cli.public_key_path)
    )
    key_manager.generate_keys(key_size=key_size)
    key_manager.save_keys()
    print(f"{Fore.GREEN}   ✓ Keys generated and saved")
    
    # Get default password
    print(f"\n{Fore.CYAN}2. Setting up default encryption password...")
    while True:
        password = getpass("   Enter default password: ")
        password_confirm = getpass("   Confirm password: ")
        
        if password == password_confirm:
            if len(password) < 8:
                print(f"{Fore.RED}   Password must be at least 8 characters!")
                continue
            break
        else:
            print(f"{Fore.RED}   Passwords don't match! Try again.")
    
    # Create configuration
    print(f"\n{Fore.CYAN}3. Creating configuration...")
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    config_manager.set_default_password(password)
    
    # Set mount point
    if mount_point:
        config_manager.set_mount_point(mount_point)
    else:
        default_mount = str(Path.home() / "cryptbox_mount")
        config_manager.set_mount_point(default_mount)
    
    # Set storage path
    if storage:
        config_manager.set_encrypted_storage(storage)
    else:
        default_storage = str(Path.home() / "Dropbox" / "cryptbox" / "__enc__")
        config_manager.set_encrypted_storage(default_storage)
    
    config_manager.set_key_directory(str(cryptbox_cli.key_dir))
    print(f"{Fore.GREEN}   ✓ Configuration saved")
    
    # Create directories
    mount_point_path = Path(config_manager.get_mount_point())
    storage_path = Path(config_manager.get_encrypted_storage())
    
    mount_point_path.mkdir(parents=True, exist_ok=True)
    storage_path.mkdir(parents=True, exist_ok=True)
    
    # Summary
    print(f"\n{Fore.GREEN}{'='*60}")
    print(f"{Fore.GREEN}✓ Cryptbox initialized successfully!")
    print(f"{Fore.GREEN}{'='*60}")
    print(f"\n{Fore.CYAN}Configuration:")
    print(f"  Mount Point:      {mount_point_path}")
    print(f"  Encrypted Storage: {storage_path}")
    print(f"  Config File:      {cryptbox_cli.config_path}")
    print(f"  Keys Directory:   {cryptbox_cli.key_dir}")
    
    print(f"\n{Fore.YELLOW}Next Steps:")
    print(f"  1. Mount filesystem:  {Fore.WHITE}cryptbox mount")
    print(f"  2. Access files at:   {Fore.WHITE}{mount_point_path}")
    print(f"  3. Share your public key: {Fore.WHITE}cryptbox export-key")


@cli.command()
@click.option('--foreground', '-f', is_flag=True, help='Run in foreground')
@click.option('--debug', '-d', is_flag=True, help='Enable debug logging')
def mount(foreground, debug):
    """Mount Cryptbox filesystem."""
    cryptbox_cli = CryptboxCLI()
    
    # Check if initialized
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox not initialized!")
        print(f"  Run: {Fore.WHITE}cryptbox init")
        return
    
    # Load configuration
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    mount_point = config_manager.get_mount_point()
    storage = config_manager.get_encrypted_storage()
    
    # Check if already mounted
    if os.path.ismount(mount_point):
        print(f"{Fore.YELLOW}⚠ Cryptbox already mounted at: {mount_point}")
        return
    
    print(f"{Fore.CYAN}Mounting Cryptbox...")
    print(f"  Mount Point: {mount_point}")
    print(f"  Storage: {storage}")
    
    if not foreground:
        print(f"\n{Fore.GREEN}✓ Mounting in background...")
        print(f"  To unmount: {Fore.WHITE}cryptbox unmount")
    
    try:
        mount_cryptbox(
            mount_point,
            storage,
            str(cryptbox_cli.config_path),
            foreground=foreground
        )
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Unmounting...")
    except Exception as e:
        print(f"{Fore.RED}✗ Mount failed: {e}")


@cli.command()
def unmount():
    """Unmount Cryptbox filesystem."""
    cryptbox_cli = CryptboxCLI()
    
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox not initialized!")
        return
    
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    mount_point = config_manager.get_mount_point()
    
    if not os.path.ismount(mount_point):
        print(f"{Fore.YELLOW}⚠ Cryptbox not mounted")
        return
    
    print(f"{Fore.CYAN}Unmounting Cryptbox from: {mount_point}")
    
    try:
        # Use fusermount to unmount
        subprocess.run(['fusermount', '-u', mount_point], check=True)
        print(f"{Fore.GREEN}✓ Unmounted successfully")
    except subprocess.CalledProcessError:
        try:
            # Try umount as fallback
            subprocess.run(['umount', mount_point], check=True)
            print(f"{Fore.GREEN}✓ Unmounted successfully")
        except:
            print(f"{Fore.RED}✗ Failed to unmount. Try manually:")
            print(f"  fusermount -u {mount_point}")


@cli.command()
def status():
    """Show Cryptbox status."""
    cryptbox_cli = CryptboxCLI()
    cryptbox_cli.print_banner()
    
    print(f"{Fore.CYAN}Status Check:\n")
    
    # Check initialization
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Not initialized")
        print(f"  Run: {Fore.WHITE}cryptbox init")
        return
    
    print(f"{Fore.GREEN}✓ Initialized")
    
    # Load config
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    mount_point = config_manager.get_mount_point()
    storage = config_manager.get_encrypted_storage()
    
    # Check mount status
    is_mounted = os.path.ismount(mount_point)
    mount_status = f"{Fore.GREEN}✓ Mounted" if is_mounted else f"{Fore.YELLOW}○ Not mounted"
    
    print(f"\n{Fore.CYAN}Configuration:")
    print(f"  Mount Point:       {mount_point}")
    print(f"  Status:            {mount_status}")
    print(f"  Encrypted Storage: {storage}")
    print(f"  Config:            {cryptbox_cli.config_path}")
    print(f"  Keys:              {cryptbox_cli.key_dir}")
    
    # Count configured files
    num_files = len(config_manager.list_encrypted_files())
    print(f"\n{Fore.CYAN}Files:")
    print(f"  Configured files: {num_files}")


@cli.command()
@click.argument('output_path', default='my_public_key.json')
@click.option('--name', prompt='Your name', help='Your name')
@click.option('--email', prompt='Your email', help='Your email')
def export_key(output_path, name, email):
    """Export public key for sharing."""
    cryptbox_cli = CryptboxCLI()
    
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox not initialized!")
        return
    
    # Load keys
    key_manager = RSAKeyManager(
        str(cryptbox_cli.private_key_path),
        str(cryptbox_cli.public_key_path)
    )
    key_manager.load_keys()
    
    # Export
    user_info = {"name": name, "email": email}
    KeyExchange.export_public_key(key_manager, output_path, user_info)
    
    print(f"\n{Fore.GREEN}✓ Public key exported!")
    print(f"  Share this file with others: {Fore.WHITE}{output_path}")


@cli.command()
@click.argument('file_path')
@click.argument('recipient_keys', nargs=-1, required=True)
@click.option('--output', '-o', default=None, help='Output bundle path')
def share(file_path, recipient_keys, output):
    """Share a file with recipients."""
    cryptbox_cli = CryptboxCLI()
    
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox not initialized!")
        return
    
    print(f"{Fore.CYAN}Sharing file: {file_path}")
    print(f"  Recipients: {len(recipient_keys)}")
    
    # Load managers
    key_manager = RSAKeyManager(
        str(cryptbox_cli.private_key_path),
        str(cryptbox_cli.public_key_path)
    )
    key_manager.load_keys()
    
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    sharing = SecureSharing(key_manager, config_manager)
    
    try:
        bundle_path = sharing.share_file(file_path, list(recipient_keys), output)
        print(f"\n{Fore.GREEN}✓ Sharing bundle created: {bundle_path}")
        print(f"  Send this file to recipients")
    except Exception as e:
        print(f"{Fore.RED}✗ Failed to create sharing bundle: {e}")


@cli.command()
@click.argument('bundle_path')
@click.argument('encrypted_file_path')
def receive(bundle_path, encrypted_file_path):
    """Receive a shared file."""
    cryptbox_cli = CryptboxCLI()
    
    if not cryptbox_cli.is_initialized():
        print(f"{Fore.RED}✗ Cryptbox not initialized!")
        return
    
    print(f"{Fore.CYAN}Receiving shared file...")
    
    # Load managers
    key_manager = RSAKeyManager(
        str(cryptbox_cli.private_key_path),
        str(cryptbox_cli.public_key_path)
    )
    key_manager.load_keys()
    
    config_manager = ConfigManager(str(cryptbox_cli.config_path))
    sharing = SecureSharing(key_manager, config_manager)
    
    if sharing.receive_shared_file(bundle_path, encrypted_file_path):
        print(f"\n{Fore.GREEN}✓ File received successfully!")
        print(f"  You can now access: {encrypted_file_path}")
    else:
        print(f"{Fore.RED}✗ Failed to receive file")


def main():
    """Main entry point."""
    try:
        cli()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Interrupted")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Fore.RED}Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()