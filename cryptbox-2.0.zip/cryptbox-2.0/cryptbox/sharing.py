"""
Cryptbox 2.0 - Secure Sharing Protocol

Implements secure password sharing between users using RSA encryption.
Addresses the original Cryptbox limitation of not having password distribution infrastructure.
"""

import json
import base64
import hashlib
from typing import Dict, List, Optional
from pathlib import Path
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

from cryptbox.key_manager import RSAKeyManager
from cryptbox.config_manager import ConfigManager


class SecureSharing:
    """
    Manages secure sharing of encrypted files between users.
    Uses RSA to encrypt file passwords for sharing.
    """
    
    SHARING_VERSION = "2.0"
    
    def __init__(self, 
                 key_manager: RSAKeyManager,
                 config_manager: ConfigManager):
        """
        Initialize SecureSharing.
        
        Args:
            key_manager: RSA key manager
            config_manager: Configuration manager
        """
        self.key_manager = key_manager
        self.config_manager = config_manager
    
    def _hash_public_key(self, public_key_pem: str) -> str:
        """
        Create hash identifier for a public key.
        
        Args:
            public_key_pem: PEM-encoded public key
            
        Returns:
            SHA-256 hash of public key (first 16 chars)
        """
        key_hash = hashlib.sha256(public_key_pem.encode()).hexdigest()
        return key_hash[:16]
    
    def encrypt_password_for_recipient(self, 
                                      password: str,
                                      recipient_public_key_pem: str) -> str:
        """
        Encrypt a password using recipient's public key.
        
        Args:
            password: Password to encrypt
            recipient_public_key_pem: Recipient's public key in PEM format
            
        Returns:
            Base64-encoded encrypted password
        """
        try:
            # Load recipient's public key
            recipient_key = RSA.import_key(recipient_public_key_pem)
            
            # Create cipher
            cipher = PKCS1_OAEP.new(recipient_key)
            
            # Encrypt password
            encrypted_password = cipher.encrypt(password.encode('utf-8'))
            
            # Return as base64
            return base64.b64encode(encrypted_password).decode('utf-8')
            
        except Exception as e:
            raise Exception(f"Failed to encrypt password: {str(e)}")
    
    def decrypt_password_for_self(self, encrypted_password: str) -> str:
        """
        Decrypt a password using own private key.
        
        Args:
            encrypted_password: Base64-encoded encrypted password
            
        Returns:
            Decrypted password
        """
        try:
            # Decode from base64
            encrypted_data = base64.b64decode(encrypted_password)
            
            # Get own private key
            private_key = self.key_manager.get_private_key()
            
            # Create cipher
            cipher = PKCS1_OAEP.new(private_key)
            
            # Decrypt password
            password = cipher.decrypt(encrypted_data)
            
            return password.decode('utf-8')
            
        except Exception as e:
            raise Exception(f"Failed to decrypt password: {str(e)}")
    
    def create_sharing_bundle(self,
                            file_path: str,
                            password: str,
                            recipient_public_keys: List[str]) -> Dict:
        """
        Create a sharing bundle for a file.
        
        Args:
            file_path: Path to the file
            password: File password to share
            recipient_public_keys: List of recipient public keys (PEM format)
            
        Returns:
            Sharing bundle dictionary
        """
        sharing_bundle = {
            "version": self.SHARING_VERSION,
            "file_path": file_path,
            "owner_public_key": self.key_manager.export_public_key(),
            "encrypted_passwords": {}
        }
        
        # Encrypt password for each recipient
        for recipient_key in recipient_public_keys:
            key_hash = self._hash_public_key(recipient_key)
            encrypted_pwd = self.encrypt_password_for_recipient(password, recipient_key)
            
            sharing_bundle["encrypted_passwords"][key_hash] = {
                "public_key": recipient_key,
                "encrypted_password": encrypted_pwd
            }
        
        return sharing_bundle
    
    def save_sharing_bundle(self, 
                           sharing_bundle: Dict,
                           output_path: str):
        """
        Save sharing bundle to file.
        
        Args:
            sharing_bundle: Sharing bundle dictionary
            output_path: Path to save bundle
        """
        try:
            with open(output_path, 'w') as f:
                json.dump(sharing_bundle, f, indent=2)
        except Exception as e:
            raise Exception(f"Failed to save sharing bundle: {str(e)}")
    
    def load_sharing_bundle(self, bundle_path: str) -> Dict:
        """
        Load sharing bundle from file.
        
        Args:
            bundle_path: Path to bundle file
            
        Returns:
            Sharing bundle dictionary
        """
        try:
            with open(bundle_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            raise Exception(f"Failed to load sharing bundle: {str(e)}")
    
    def extract_password_from_bundle(self, sharing_bundle: Dict) -> Optional[str]:
        """
        Extract password from sharing bundle using own private key.
        
        Args:
            sharing_bundle: Sharing bundle dictionary
            
        Returns:
            Decrypted password or None if not found
        """
        # Get own public key hash
        own_public_key = self.key_manager.export_public_key()
        own_key_hash = self._hash_public_key(own_public_key)
        
        # Find encrypted password for self
        encrypted_passwords = sharing_bundle.get("encrypted_passwords", {})
        
        if own_key_hash in encrypted_passwords:
            encrypted_pwd = encrypted_passwords[own_key_hash]["encrypted_password"]
            return self.decrypt_password_for_self(encrypted_pwd)
        
        return None
    
    def share_file(self,
                  file_path: str,
                  recipient_public_key_files: List[str],
                  output_bundle_path: Optional[str] = None) -> str:
        """
        Share a file with recipients.
        
        Args:
            file_path: Path to file to share
            recipient_public_key_files: List of paths to recipient public key files
            output_bundle_path: Optional path for sharing bundle
            
        Returns:
            Path to sharing bundle file
        """
        # Get file password
        password = self.config_manager.get_file_password(file_path)
        if not password:
            raise Exception(f"No password configured for file: {file_path}")
        
        # Load recipient public keys
        recipient_keys = []
        for key_file in recipient_public_key_files:
            try:
                with open(key_file, 'r') as f:
                    recipient_keys.append(f.read())
            except Exception as e:
                print(f"Warning: Could not load key from {key_file}: {e}")
        
        if not recipient_keys:
            raise Exception("No valid recipient public keys provided")
        
        # Create sharing bundle
        bundle = self.create_sharing_bundle(file_path, password, recipient_keys)
        
        # Determine output path
        if output_bundle_path is None:
            file_name = Path(file_path).name
            output_bundle_path = f"{file_name}.sharing_bundle.json"
        
        # Save bundle
        self.save_sharing_bundle(bundle, output_bundle_path)
        
        return output_bundle_path
    
    def receive_shared_file(self, 
                           bundle_path: str,
                           encrypted_file_path: str) -> bool:
        """
        Receive a shared file by extracting password from bundle.
        
        Args:
            bundle_path: Path to sharing bundle
            encrypted_file_path: Path to encrypted file
            
        Returns:
            True if successful
        """
        try:
            # Load bundle
            bundle = self.load_sharing_bundle(bundle_path)
            
            # Extract password
            password = self.extract_password_from_bundle(bundle)
            if not password:
                raise Exception("Could not extract password - you may not be a recipient")
            
            # Add to config
            self.config_manager.set_file_password(encrypted_file_path, password)
            
            print(f"✓ Successfully received shared file")
            print(f"  File: {encrypted_file_path}")
            print(f"  Password configured in Cryptbox")
            
            return True
            
        except Exception as e:
            print(f"Failed to receive shared file: {e}")
            return False


class KeyExchange:
    """
    Facilitates public key exchange between users.
    Simple implementation for distributing public keys.
    """
    
    @staticmethod
    def export_public_key(key_manager: RSAKeyManager, 
                         output_path: str,
                         user_info: Optional[Dict] = None):
        """
        Export public key with optional user information.
        
        Args:
            key_manager: RSA key manager
            output_path: Path to save public key
            user_info: Optional user information (name, email, etc.)
        """
        public_key_pem = key_manager.export_public_key()
        
        export_data = {
            "public_key": public_key_pem,
            "user_info": user_info or {},
            "key_type": "RSA-2048",
            "usage": "Cryptbox 2.0 File Sharing"
        }
        
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"✓ Public key exported to: {output_path}")
    
    @staticmethod
    def import_public_key(import_path: str) -> tuple:
        """
        Import public key from file.
        
        Args:
            import_path: Path to public key file
            
        Returns:
            Tuple of (public_key_pem, user_info)
        """
        with open(import_path, 'r') as f:
            data = json.load(f)
        
        return data["public_key"], data.get("user_info", {})


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - Secure Sharing Demo ===\n")
    
    from cryptbox.config_manager import ConfigManager
    
    # Setup for Alice (sender)
    print("1. Setting up Alice (sender):")
    alice_key_mgr = RSAKeyManager()
    alice_key_mgr.generate_keys()
    alice_config = ConfigManager("/tmp/alice_config.json")
    alice_config.set_default_password("alice_default")
    alice_sharing = SecureSharing(alice_key_mgr, alice_config)
    print("   ✓ Alice initialized\n")
    
    # Setup for Bob (receiver)
    print("2. Setting up Bob (receiver):")
    bob_key_mgr = RSAKeyManager()
    bob_key_mgr.generate_keys()
    bob_config = ConfigManager("/tmp/bob_config.json")
    bob_config.set_default_password("bob_default")
    bob_sharing = SecureSharing(bob_key_mgr, bob_config)
    print("   ✓ Bob initialized\n")
    
    # Alice exports her public key
    print("3. Alice exports public key:")
    KeyExchange.export_public_key(
        alice_key_mgr,
        "/tmp/alice_public.json",
        {"name": "Alice", "email": "alice@example.com"}
    )
    
    # Bob exports his public key
    print("\n4. Bob exports public key:")
    KeyExchange.export_public_key(
        bob_key_mgr,
        "/tmp/bob_public.json",
        {"name": "Bob", "email": "bob@example.com"}
    )
    
    # Alice wants to share a file with Bob
    print("\n5. Alice creates sharing bundle:")
    file_path = "/encrypted/secret_document.txt"
    file_password = "super_secret_password_123"
    alice_config.set_file_password(file_path, file_password)
    
    # Import Bob's public key
    bob_public_key, bob_info = KeyExchange.import_public_key("/tmp/bob_public.json")
    print(f"   Sharing with: {bob_info.get('name')} ({bob_info.get('email')})")
    
    # Create sharing bundle
    bundle = alice_sharing.create_sharing_bundle(
        file_path,
        file_password,
        [bob_public_key]
    )
    alice_sharing.save_sharing_bundle(bundle, "/tmp/sharing_bundle.json")
    print("   ✓ Sharing bundle created\n")
    
    # Bob receives the shared file
    print("6. Bob receives shared file:")
    success = bob_sharing.receive_shared_file(
        "/tmp/sharing_bundle.json",
        file_path
    )
    
    if success:
        # Verify Bob can get the password
        bob_password = bob_config.get_file_password(file_path)
        print(f"\n7. Verification:")
        print(f"   Alice's password: {file_password}")
        print(f"   Bob's password:   {bob_password}")
        print(f"   Match: {file_password == bob_password}")
    
    # Cleanup
    import os
    for f in ["/tmp/alice_config.json", "/tmp/bob_config.json", 
              "/tmp/alice_public.json", "/tmp/bob_public.json",
              "/tmp/sharing_bundle.json"]:
        try:
            os.remove(f)
        except:
            pass
    
    print("\n✅ Secure sharing demo completed!")