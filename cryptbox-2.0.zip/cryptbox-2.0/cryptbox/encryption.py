"""
Cryptbox 2.0 - File Encryption Module

Handles file encryption and decryption using:
- AES-256-GCM for authenticated encryption
- PBKDF2-SHA256 for key derivation from passwords
"""

import os
from pathlib import Path
from typing import Optional
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from utils.crypto_utils import derive_key, generate_salt


class FileEncryptor:
    """
    Handles file encryption and decryption operations.
    Uses AES-256-GCM for authenticated encryption.
    """
    
    SALT_SIZE = 16  # 16 bytes salt
    NONCE_SIZE = 12  # 12 bytes nonce for GCM
    TAG_SIZE = 16   # 16 bytes authentication tag
    KEY_SIZE = 32   # 32 bytes (256 bits) for AES-256
    
    def __init__(self):
        """Initialize FileEncryptor."""
        pass
    
    def encrypt_file(self, 
                    input_path: str, 
                    output_path: str, 
                    password: str):
        """
        Encrypt a file using AES-256-GCM.
        
        File format:
        [SALT (16 bytes)][NONCE (12 bytes)][TAG (16 bytes)][CIPHERTEXT]
        
        Args:
            input_path: Path to plaintext file
            output_path: Path to save encrypted file
            password: Password for encryption
        """
        try:
            # Read plaintext
            with open(input_path, 'rb') as f:
                plaintext = f.read()
            
            # Generate salt and derive key
            salt = generate_salt(self.SALT_SIZE)
            key = derive_key(password, salt, key_length=self.KEY_SIZE)
            
            # Generate nonce
            nonce = get_random_bytes(self.NONCE_SIZE)
            
            # Create cipher
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            
            # Encrypt and get authentication tag
            ciphertext, tag = cipher.encrypt_and_digest(plaintext)
            
            # Write encrypted file: salt + nonce + tag + ciphertext
            with open(output_path, 'wb') as f:
                f.write(salt)
                f.write(nonce)
                f.write(tag)
                f.write(ciphertext)
            
        except Exception as e:
            raise Exception(f"Encryption failed: {str(e)}")
    
    def decrypt_file(self,
                    input_path: str,
                    output_path: str,
                    password: str):
        """
        Decrypt a file encrypted with encrypt_file().
        
        Args:
            input_path: Path to encrypted file
            output_path: Path to save decrypted file
            password: Password for decryption
        """
        try:
            # Read encrypted file
            with open(input_path, 'rb') as f:
                encrypted_data = f.read()
            
            # Extract components
            salt = encrypted_data[:self.SALT_SIZE]
            nonce = encrypted_data[self.SALT_SIZE:self.SALT_SIZE + self.NONCE_SIZE]
            tag = encrypted_data[self.SALT_SIZE + self.NONCE_SIZE:
                                self.SALT_SIZE + self.NONCE_SIZE + self.TAG_SIZE]
            ciphertext = encrypted_data[self.SALT_SIZE + self.NONCE_SIZE + self.TAG_SIZE:]
            
            # Derive key from password and salt
            key = derive_key(password, salt, key_length=self.KEY_SIZE)
            
            # Create cipher
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            
            # Decrypt and verify authentication tag
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
            
            # Write decrypted file
            with open(output_path, 'wb') as f:
                f.write(plaintext)
            
        except ValueError as e:
            raise Exception(f"Decryption failed - wrong password or corrupted file: {str(e)}")
        except Exception as e:
            raise Exception(f"Decryption failed: {str(e)}")
    
    def encrypt_bytes(self, plaintext: bytes, password: str) -> bytes:
        """
        Encrypt bytes using AES-256-GCM.
        
        Args:
            plaintext: Data to encrypt
            password: Password for encryption
            
        Returns:
            Encrypted data (salt + nonce + tag + ciphertext)
        """
        try:
            # Generate salt and derive key
            salt = generate_salt(self.SALT_SIZE)
            key = derive_key(password, salt, key_length=self.KEY_SIZE)
            
            # Generate nonce
            nonce = get_random_bytes(self.NONCE_SIZE)
            
            # Create cipher
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            
            # Encrypt
            ciphertext, tag = cipher.encrypt_and_digest(plaintext)
            
            # Return: salt + nonce + tag + ciphertext
            return salt + nonce + tag + ciphertext
            
        except Exception as e:
            raise Exception(f"Encryption failed: {str(e)}")
    
    def decrypt_bytes(self, encrypted_data: bytes, password: str) -> bytes:
        """
        Decrypt bytes encrypted with encrypt_bytes().
        
        Args:
            encrypted_data: Encrypted data
            password: Password for decryption
            
        Returns:
            Decrypted plaintext
        """
        try:
            # Extract components
            salt = encrypted_data[:self.SALT_SIZE]
            nonce = encrypted_data[self.SALT_SIZE:self.SALT_SIZE + self.NONCE_SIZE]
            tag = encrypted_data[self.SALT_SIZE + self.NONCE_SIZE:
                                self.SALT_SIZE + self.NONCE_SIZE + self.TAG_SIZE]
            ciphertext = encrypted_data[self.SALT_SIZE + self.NONCE_SIZE + self.TAG_SIZE:]
            
            # Derive key
            key = derive_key(password, salt, key_length=self.KEY_SIZE)
            
            # Create cipher
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            
            # Decrypt and verify
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
            
            return plaintext
            
        except ValueError as e:
            raise Exception(f"Decryption failed - wrong password or corrupted data: {str(e)}")
        except Exception as e:
            raise Exception(f"Decryption failed: {str(e)}")


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - File Encryption Demo ===\n")
    
    # Initialize encryptor
    encryptor = FileEncryptor()
    
    # Create test directory
    test_dir = Path("/tmp/cryptbox_encryption_test")
    test_dir.mkdir(exist_ok=True)
    
    # Test 1: File encryption/decryption
    print("1. File Encryption/Decryption:")
    plaintext_file = test_dir / "plaintext.txt"
    encrypted_file = test_dir / "encrypted.enc"
    decrypted_file = test_dir / "decrypted.txt"
    
    # Create test file
    test_content = "This is secret content for Cryptbox 2.0!\nLine 2 of secret data."
    plaintext_file.write_text(test_content)
    print(f"   Original: {test_content[:50]}...")
    
    # Encrypt
    password = "secure_password_123"
    encryptor.encrypt_file(str(plaintext_file), str(encrypted_file), password)
    print(f"   ✓ File encrypted: {encrypted_file}")
    
    # Show encrypted content (should be unreadable)
    encrypted_content = encrypted_file.read_bytes()
    print(f"   Encrypted (first 32 bytes hex): {encrypted_content[:32].hex()}")
    
    # Decrypt
    encryptor.decrypt_file(str(encrypted_file), str(decrypted_file), password)
    decrypted_content = decrypted_file.read_text()
    print(f"   ✓ File decrypted: {decrypted_file}")
    print(f"   Decrypted: {decrypted_content[:50]}...")
    
    # Verify
    assert test_content == decrypted_content
    print("   ✓ Content matches!")
    print()
    
    # Test 2: Wrong password
    print("2. Testing Wrong Password:")
    try:
        encryptor.decrypt_file(str(encrypted_file), str(decrypted_file), "wrong_password")
        print("   ❌ Should have failed!")
    except Exception as e:
        print(f"   ✓ Correctly rejected: {str(e)[:50]}...")
    print()
    
    # Test 3: Bytes encryption/decryption
    print("3. Bytes Encryption/Decryption:")
    original_bytes = b"Secret byte data!"
    print(f"   Original: {original_bytes.decode()}")
    
    encrypted_bytes = encryptor.encrypt_bytes(original_bytes, password)
    print(f"   Encrypted (first 32 bytes hex): {encrypted_bytes[:32].hex()}")
    
    decrypted_bytes = encryptor.decrypt_bytes(encrypted_bytes, password)
    print(f"   Decrypted: {decrypted_bytes.decode()}")
    
    assert original_bytes == decrypted_bytes
    print("   ✓ Bytes match!")
    print()
    
    # Test 4: File size comparison
    print("4. File Size Analysis:")
    original_size = plaintext_file.stat().st_size
    encrypted_size = encrypted_file.stat().st_size
    overhead = encrypted_size - original_size
    
    print(f"   Original size:  {original_size} bytes")
    print(f"   Encrypted size: {encrypted_size} bytes")
    print(f"   Overhead:       {overhead} bytes (salt + nonce + tag)")
    print(f"   Expected:       {encryptor.SALT_SIZE + encryptor.NONCE_SIZE + encryptor.TAG_SIZE} bytes")
    print()
    
    # Cleanup
    plaintext_file.unlink()
    encrypted_file.unlink()
    decrypted_file.unlink()
    test_dir.rmdir()
    
    print("✅ File encryption working correctly!")