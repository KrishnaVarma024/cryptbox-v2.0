"""
Cryptbox 2.0 - Digital Signature Module

Provides digital signature functionality for:
- File integrity verification
- Authentication
- Non-repudiation
"""

import os
import base64
from pathlib import Path
from typing import Optional
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from cryptbox.key_manager import RSAKeyManager
from utils.crypto_utils import hash_file_sha256


class DigitalSignature:
    """
    Manages digital signatures for files.
    Uses RSA-PSS with SHA-256 for signing.
    """
    
    SIGNATURE_EXTENSION = ".sig"
    
    def __init__(self, key_manager: RSAKeyManager):
        """
        Initialize DigitalSignature.
        
        Args:
            key_manager: RSA key manager for signing operations
        """
        self.key_manager = key_manager
    
    def sign_file(self, file_path: str) -> str:
        """
        Create a digital signature for a file.
        
        Args:
            file_path: Path to file to sign
            
        Returns:
            Base64-encoded signature
        """
        try:
            # Read file content
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            # Sign the data
            signature = self.key_manager.sign_data(file_data)
            
            # Convert to base64 for storage
            signature_b64 = base64.b64encode(signature).decode('utf-8')
            
            # Save signature to file
            signature_path = file_path + self.SIGNATURE_EXTENSION
            with open(signature_path, 'w') as f:
                f.write(signature_b64)
            
            return signature_b64
            
        except Exception as e:
            raise Exception(f"Failed to sign file: {str(e)}")
    
    def verify_file(self, file_path: str, signature_path: Optional[str] = None) -> bool:
        """
        Verify a file's digital signature.
        
        Args:
            file_path: Path to file to verify
            signature_path: Optional path to signature file (default: file_path.sig)
            
        Returns:
            True if signature is valid, False otherwise
        """
        try:
            # Determine signature path
            if signature_path is None:
                signature_path = file_path + self.SIGNATURE_EXTENSION
            
            # Check if signature file exists
            if not os.path.exists(signature_path):
                raise Exception(f"Signature file not found: {signature_path}")
            
            # Read file content
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            # Read signature
            with open(signature_path, 'r') as f:
                signature_b64 = f.read()
            
            # Decode signature from base64
            signature = base64.b64decode(signature_b64)
            
            # Verify signature
            return self.key_manager.verify_signature(file_data, signature)
            
        except Exception as e:
            print(f"Verification error: {e}")
            return False
    
    def sign_data(self, data: bytes) -> str:
        """
        Sign arbitrary data.
        
        Args:
            data: Data to sign
            
        Returns:
            Base64-encoded signature
        """
        signature = self.key_manager.sign_data(data)
        return base64.b64encode(signature).decode('utf-8')
    
    def verify_data(self, data: bytes, signature_b64: str) -> bool:
        """
        Verify signature of arbitrary data.
        
        Args:
            data: Original data
            signature_b64: Base64-encoded signature
            
        Returns:
            True if signature is valid
        """
        try:
            signature = base64.b64decode(signature_b64)
            return self.key_manager.verify_signature(data, signature)
        except Exception as e:
            print(f"Verification error: {e}")
            return False
    
    def get_file_hash(self, file_path: str) -> str:
        """
        Get SHA-256 hash of a file.
        
        Args:
            file_path: Path to file
            
        Returns:
            Hex-encoded SHA-256 hash
        """
        return hash_file_sha256(file_path)
    
    def remove_signature(self, file_path: str):
        """
        Remove signature file for a given file.
        
        Args:
            file_path: Path to file whose signature should be removed
        """
        signature_path = file_path + self.SIGNATURE_EXTENSION
        if os.path.exists(signature_path):
            os.remove(signature_path)


class SignatureVerifier:
    """
    Utility class for verifying signatures with different public keys.
    Useful for verifying signatures from other users.
    """
    
    def __init__(self, public_key_pem: str):
        """
        Initialize SignatureVerifier with a public key.
        
        Args:
            public_key_pem: Public key in PEM format
        """
        self.public_key = RSA.import_key(public_key_pem)
    
    def verify_file(self, file_path: str, signature_b64: str) -> bool:
        """
        Verify file signature using the public key.
        
        Args:
            file_path: Path to file
            signature_b64: Base64-encoded signature
            
        Returns:
            True if signature is valid
        """
        try:
            # Read file
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            # Decode signature
            signature = base64.b64decode(signature_b64)
            
            # Verify
            h = SHA256.new(file_data)
            pkcs1_15.new(self.public_key).verify(h, signature)
            return True
            
        except (ValueError, TypeError):
            return False
        except Exception as e:
            print(f"Verification error: {e}")
            return False
    
    def verify_data(self, data: bytes, signature_b64: str) -> bool:
        """
        Verify data signature using the public key.
        
        Args:
            data: Original data
            signature_b64: Base64-encoded signature
            
        Returns:
            True if signature is valid
        """
        try:
            signature = base64.b64decode(signature_b64)
            h = SHA256.new(data)
            pkcs1_15.new(self.public_key).verify(h, signature)
            return True
        except (ValueError, TypeError):
            return False
        except Exception as e:
            print(f"Verification error: {e}")
            return False


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - Digital Signature Demo ===\n")
    
    # Setup
    from cryptbox.key_manager import RSAKeyManager
    
    # Generate keys
    print("1. Generating RSA keys...")
    key_manager = RSAKeyManager()
    key_manager.generate_keys()
    print()
    
    # Initialize signature manager
    signature_mgr = DigitalSignature(key_manager)
    
    # Create test file
    print("2. Creating test file...")
    test_dir = Path("/tmp/cryptbox_signature_test")
    test_dir.mkdir(exist_ok=True)
    
    test_file = test_dir / "document.txt"
    test_content = "This is an important document that needs to be signed!"
    test_file.write_text(test_content)
    print(f"   File: {test_file}")
    print(f"   Content: {test_content}")
    print()
    
    # Sign file
    print("3. Signing file...")
    signature = signature_mgr.sign_file(str(test_file))
    print(f"   ✓ Signature created (first 32 chars): {signature[:32]}...")
    print(f"   Signature saved to: {test_file}.sig")
    print()
    
    # Verify signature
    print("4. Verifying signature...")
    is_valid = signature_mgr.verify_file(str(test_file))
    print(f"   ✓ Signature valid: {is_valid}")
    print()
    
    # Tamper with file
    print("5. Testing tampered file...")
    test_file.write_text("This is a TAMPERED document!")
    is_valid_tampered = signature_mgr.verify_file(str(test_file))
    print(f"   ✓ Tampered signature valid: {is_valid_tampered}")
    print()
    
    # Restore original content
    test_file.write_text(test_content)
    
    # Test with another user's verification
    print("6. Testing signature verification with another user...")
    
    # Export public key
    public_key_pem = key_manager.export_public_key()
    
    # Another user verifies
    verifier = SignatureVerifier(public_key_pem)
    is_valid_external = verifier.verify_file(str(test_file), signature)
    print(f"   ✓ External verification: {is_valid_external}")
    print()
    
    # Test data signing
    print("7. Testing data signing...")
    test_data = b"Important message to sign"
    data_signature = signature_mgr.sign_data(test_data)
    print(f"   Data: {test_data.decode()}")
    print(f"   Signature (first 32 chars): {data_signature[:32]}...")
    
    is_data_valid = signature_mgr.verify_data(test_data, data_signature)
    print(f"   ✓ Data signature valid: {is_data_valid}")
    print()
    
    # Get file hash
    print("8. File hash (for reference)...")
    file_hash = signature_mgr.get_file_hash(str(test_file))
    print(f"   SHA-256: {file_hash}")
    print()
    
    # Cleanup
    signature_mgr.remove_signature(str(test_file))
    test_file.unlink()
    test_dir.rmdir()
    
    print("✅ Digital signatures working correctly!")