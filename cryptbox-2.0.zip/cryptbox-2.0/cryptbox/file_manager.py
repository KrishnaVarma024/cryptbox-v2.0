"""
Cryptbox 2.0 - File Manager

Manages open decrypted files and handles encryption/decryption operations.
Similar to the original DecryptedFileManager but with enhanced security.
"""

import os
import tempfile
import threading
from typing import Dict, Optional
from pathlib import Path
from cryptbox.encryption import FileEncryptor
from cryptbox.signature import DigitalSignature
from cryptbox.metadata import MetadataManager


class OpenDecryptedFile:
    """
    Represents a handle to an open decrypted file.
    Manages temporary decrypted file and automatic encryption on close.
    """
    
    def __init__(self,
                 encrypted_path: str,
                 password: str,
                 file_encryptor: FileEncryptor,
                 signature_manager: Optional[DigitalSignature] = None):
        """
        Initialize an open decrypted file.
        
        Args:
            encrypted_path: Path to encrypted file on disk
            password: Password to decrypt the file
            file_encryptor: FileEncryptor instance
            signature_manager: Optional signature manager for verification
        """
        self.encrypted_path = encrypted_path
        self.password = password
        self.file_encryptor = file_encryptor
        self.signature_manager = signature_manager
        
        # Create temporary file for decrypted content
        self.temp_fd, self.temp_path = tempfile.mkstemp(suffix=".cryptbox_tmp")
        os.close(self.temp_fd)  # Close the fd, we'll open it properly later
        
        self.is_open = True
        self.is_modified = False
        self.lock = threading.Lock()
    
    def decrypt_to_temp(self) -> bool:
        """
        Decrypt the encrypted file to temporary location.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            with self.lock:
                # Check if encrypted file exists
                if not os.path.exists(self.encrypted_path):
                    # New file - create empty temp file
                    open(self.temp_path, 'w').close()
                    return True
                
                # Decrypt file
                self.file_encryptor.decrypt_file(
                    self.encrypted_path,
                    self.temp_path,
                    self.password
                )
                
                # Verify signature if signature manager available
                if self.signature_manager:
                    try:
                        is_valid = self.signature_manager.verify_file(self.temp_path)
                        if not is_valid:
                            print(f"Warning: Signature verification failed for {self.encrypted_path}")
                    except Exception as e:
                        print(f"Signature verification error: {e}")
                
                return True
                
        except Exception as e:
            print(f"Error decrypting file: {e}")
            return False
    
    def encrypt_from_temp(self) -> bool:
        """
        Encrypt the temporary file back to encrypted location.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            with self.lock:
                # Sign file if signature manager available
                if self.signature_manager:
                    try:
                        self.signature_manager.sign_file(self.temp_path)
                    except Exception as e:
                        print(f"Signature creation error: {e}")
                
                # Encrypt file
                self.file_encryptor.encrypt_file(
                    self.temp_path,
                    self.encrypted_path,
                    self.password
                )
                
                self.is_modified = False
                return True
                
        except Exception as e:
            print(f"Error encrypting file: {e}")
            return False
    
    def read(self, offset: int, size: int) -> bytes:
        """
        Read data from temporary decrypted file.
        
        Args:
            offset: Byte offset to start reading
            size: Number of bytes to read
            
        Returns:
            Bytes read from file
        """
        with self.lock:
            with open(self.temp_path, 'rb') as f:
                f.seek(offset)
                return f.read(size)
    
    def write(self, data: bytes, offset: int) -> int:
        """
        Write data to temporary decrypted file.
        
        Args:
            data: Data to write
            offset: Byte offset to start writing
            
        Returns:
            Number of bytes written
        """
        with self.lock:
            with open(self.temp_path, 'r+b') as f:
                f.seek(offset)
                bytes_written = f.write(data)
                self.is_modified = True
                return bytes_written
    
    def truncate(self, length: int):
        """
        Truncate temporary file to specified length.
        
        Args:
            length: New file length in bytes
        """
        with self.lock:
            with open(self.temp_path, 'r+b') as f:
                f.truncate(length)
                self.is_modified = True
    
    def get_size(self) -> int:
        """
        Get size of temporary decrypted file.
        
        Returns:
            File size in bytes
        """
        return os.path.getsize(self.temp_path)
    
    def flush(self):
        """Flush changes to encrypted file."""
        if self.is_modified:
            self.encrypt_from_temp()
    
    def close(self):
        """Close file and clean up temporary file."""
        try:
            with self.lock:
                # Encrypt if modified
                if self.is_modified:
                    self.encrypt_from_temp()
                
                # Remove temporary file
                if os.path.exists(self.temp_path):
                    os.remove(self.temp_path)
                
                self.is_open = False
        except Exception as e:
            print(f"Error closing file: {e}")


class DecryptedFileManager:
    """
    Manages all open decrypted files.
    Handles concurrent access with proper synchronization.
    """
    
    def __init__(self,
                 file_encryptor: FileEncryptor,
                 signature_manager: Optional[DigitalSignature] = None):
        """
        Initialize DecryptedFileManager.
        
        Args:
            file_encryptor: FileEncryptor instance
            signature_manager: Optional signature manager
        """
        self.file_encryptor = file_encryptor
        self.signature_manager = signature_manager
        self.open_files: Dict[str, OpenDecryptedFile] = {}
        self.lock = threading.Lock()
    
    def open(self, encrypted_path: str, password: str) -> OpenDecryptedFile:
        """
        Open an encrypted file for reading/writing.
        
        Args:
            encrypted_path: Path to encrypted file
            password: Password to decrypt file
            
        Returns:
            OpenDecryptedFile handle
        """
        with self.lock:
            # Check if file is already open
            if encrypted_path in self.open_files:
                return self.open_files[encrypted_path]
            
            # Create new OpenDecryptedFile
            decrypted_file = OpenDecryptedFile(
                encrypted_path,
                password,
                self.file_encryptor,
                self.signature_manager
            )
            
            # Decrypt to temp file
            if not decrypted_file.decrypt_to_temp():
                raise Exception(f"Failed to decrypt file: {encrypted_path}")
            
            # Store in open files dict
            self.open_files[encrypted_path] = decrypted_file
            
            return decrypted_file
    
    def close(self, encrypted_path: str):
        """
        Close an open encrypted file.
        
        Args:
            encrypted_path: Path to encrypted file
        """
        with self.lock:
            if encrypted_path in self.open_files:
                decrypted_file = self.open_files[encrypted_path]
                decrypted_file.close()
                del self.open_files[encrypted_path]
    
    def flush(self, encrypted_path: str):
        """
        Flush changes for an open file.
        
        Args:
            encrypted_path: Path to encrypted file
        """
        with self.lock:
            if encrypted_path in self.open_files:
                self.open_files[encrypted_path].flush()
    
    def is_open(self, encrypted_path: str) -> bool:
        """
        Check if file is currently open.
        
        Args:
            encrypted_path: Path to encrypted file
            
        Returns:
            True if file is open
        """
        return encrypted_path in self.open_files
    
    def get_open_file(self, encrypted_path: str) -> Optional[OpenDecryptedFile]:
        """
        Get handle to open file.
        
        Args:
            encrypted_path: Path to encrypted file
            
        Returns:
            OpenDecryptedFile or None
        """
        return self.open_files.get(encrypted_path)
    
    def close_all(self):
        """Close all open files."""
        with self.lock:
            paths = list(self.open_files.keys())
            for path in paths:
                self.close(path)
    
    def get_open_count(self) -> int:
        """
        Get number of currently open files.
        
        Returns:
            Number of open files
        """
        return len(self.open_files)


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - File Manager Demo ===\n")
    
    # Setup
    from cryptbox.key_manager import RSAKeyManager
    
    password = "test_password_123"
    test_dir = Path("/tmp/cryptbox_test")
    test_dir.mkdir(exist_ok=True)
    
    encrypted_file = test_dir / "test_encrypted.enc"
    
    # Initialize managers
    key_manager = RSAKeyManager()
    key_manager.generate_keys()
    
    file_encryptor = FileEncryptor()
    signature_manager = DigitalSignature(key_manager)
    
    file_manager = DecryptedFileManager(file_encryptor, signature_manager)
    
    print("1. Creating and encrypting test file:")
    # Create test file
    test_content = b"Hello, Cryptbox 2.0! This is secret data."
    temp_file = test_dir / "test_plain.txt"
    temp_file.write_bytes(test_content)
    
    # Encrypt it
    file_encryptor.encrypt_file(str(temp_file), str(encrypted_file), password)
    print(f"Created encrypted file: {encrypted_file}")
    print()
    
    print("2. Opening encrypted file:")
    # Open file
    open_file = file_manager.open(str(encrypted_file), password)
    print(f"File opened successfully")
    print(f"File size: {open_file.get_size()} bytes")
    print()
    
    print("3. Reading decrypted content:")
    # Read content
    content = open_file.read(0, open_file.get_size())
    print(f"Content: {content.decode()}")
    print()
    
    print("4. Writing new content:")
    # Write new content
    new_content = b"Updated content - Cryptbox 2.0 is working!"
    open_file.write(new_content, 0)
    open_file.truncate(len(new_content))
    print(f"New content written: {new_content.decode()}")
    print()
    
    print("5. Closing file (auto-encrypt):")
    # Close file (will auto-encrypt)
    file_manager.close(str(encrypted_file))
    print("File closed and re-encrypted")
    print()
    
    print("6. Re-opening to verify:")
    # Re-open to verify
    open_file2 = file_manager.open(str(encrypted_file), password)
    verified_content = open_file2.read(0, open_file2.get_size())
    print(f"Verified content: {verified_content.decode()}")
    file_manager.close(str(encrypted_file))
    print()
    
    print("7. File Manager Stats:")
    print(f"Currently open files: {file_manager.get_open_count()}")
    
    # Cleanup
    temp_file.unlink(missing_ok=True)
    encrypted_file.unlink(missing_ok=True)
    
    print("\n✅ File manager working correctly!")