"""
Cryptbox 2.0 - Configuration Manager

Manages configuration files including:
- Default passwords
- File-specific passwords
- Mount points
- User preferences
"""

import json
import os
from typing import Dict, Optional, Any
from pathlib import Path
from cryptbox.key_manager import RSAKeyManager


class ConfigManager:
    """
    Manages Cryptbox configuration including passwords and settings.
    """
    
    CONFIG_VERSION = "2.0"
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize ConfigManager.
        
        Args:
            config_path: Path to config file (default: ~/.cryptbox/config.json)
        """
        if config_path is None:
            config_dir = Path.home() / ".cryptbox"
            config_dir.mkdir(exist_ok=True)
            config_path = config_dir / "config.json"
        
        self.config_path = Path(config_path)
        self.config: Dict[str, Any] = {}
        self.load_config()
    
    def load_config(self):
        """Load configuration from file."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    self.config = json.load(f)
                    
                # Validate version
                if self.config.get("version") != self.CONFIG_VERSION:
                    print(f"Warning: Config version mismatch. Expected {self.CONFIG_VERSION}")
            except Exception as e:
                print(f"Error loading config: {e}")
                self._create_default_config()
        else:
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default configuration."""
        self.config = {
            "version": self.CONFIG_VERSION,
            "default_password": None,  # Will be set during init
            "mount_point": str(Path.home() / "cryptbox_mount"),
            "encrypted_storage": str(Path.home() / "Dropbox" / "cryptbox" / "__enc__"),
            "key_directory": str(Path.home() / ".cryptbox" / "keys"),
            "files": {},  # File-specific password mappings
            "directories": {},  # Directory-specific settings
            "preferences": {
                "auto_mount": False,
                "show_hidden": False,
                "compression_enabled": False
            }
        }
        self.save_config()
    
    def save_config(self):
        """Save configuration to file."""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(self.config, indent=2, fp=f)
            
            # Set restrictive permissions (owner read/write only)
            os.chmod(self.config_path, 0o600)
        except Exception as e:
            raise Exception(f"Failed to save config: {str(e)}")
    
    def set_default_password(self, password: str):
        """
        Set default encryption password.
        
        Args:
            password: Default password for file encryption
        """
        self.config["default_password"] = password
        self.save_config()
    
    def get_default_password(self) -> Optional[str]:
        """
        Get default encryption password.
        
        Returns:
            Default password or None
        """
        return self.config.get("default_password")
    
    def set_file_password(self, file_path: str, password: str, public_keys: Optional[list] = None):
        """
        Set password for specific file with optional public key encryption.
        
        Args:
            file_path: Path to the file
            password: Password for this file
            public_keys: List of public keys to encrypt password for sharing
        """
        if "files" not in self.config:
            self.config["files"] = {}
        
        file_config = {
            "password": password,
            "encrypted_passwords": {}
        }
        
        # Encrypt password with public keys for sharing
        if public_keys:
            for pub_key in public_keys:
                try:
                    # Hash the public key to create identifier
                    import hashlib
                    key_hash = hashlib.sha256(pub_key.encode()).hexdigest()[:16]
                    
                    # This is a placeholder - actual encryption happens in sharing.py
                    file_config["encrypted_passwords"][key_hash] = {
                        "public_key": pub_key,
                        "encrypted_password": None  # Will be filled by sharing module
                    }
                except Exception as e:
                    print(f"Error processing public key: {e}")
        
        self.config["files"][file_path] = file_config
        self.save_config()
    
    def get_file_password(self, file_path: str) -> Optional[str]:
        """
        Get password for specific file.
        
        Args:
            file_path: Path to the file
            
        Returns:
            File-specific password or default password
        """
        files = self.config.get("files", {})
        file_config = files.get(file_path, {})
        
        # Return file-specific password if exists, otherwise default
        return file_config.get("password") or self.get_default_password()
    
    def remove_file_config(self, file_path: str):
        """
        Remove file-specific configuration.
        
        Args:
            file_path: Path to the file
        """
        if "files" in self.config and file_path in self.config["files"]:
            del self.config["files"][file_path]
            self.save_config()
    
    def set_mount_point(self, mount_point: str):
        """
        Set filesystem mount point.
        
        Args:
            mount_point: Path to mount point
        """
        self.config["mount_point"] = mount_point
        self.save_config()
    
    def get_mount_point(self) -> str:
        """
        Get filesystem mount point.
        
        Returns:
            Mount point path
        """
        return self.config.get("mount_point", str(Path.home() / "cryptbox_mount"))
    
    def set_encrypted_storage(self, storage_path: str):
        """
        Set encrypted storage directory path.
        
        Args:
            storage_path: Path to encrypted storage
        """
        self.config["encrypted_storage"] = storage_path
        self.save_config()
    
    def get_encrypted_storage(self) -> str:
        """
        Get encrypted storage directory path.
        
        Returns:
            Encrypted storage path
        """
        return self.config.get("encrypted_storage", 
                               str(Path.home() / "Dropbox" / "cryptbox" / "__enc__"))
    
    def set_key_directory(self, key_dir: str):
        """
        Set directory for RSA keys.
        
        Args:
            key_dir: Path to key directory
        """
        self.config["key_directory"] = key_dir
        self.save_config()
    
    def get_key_directory(self) -> str:
        """
        Get directory for RSA keys.
        
        Returns:
            Key directory path
        """
        return self.config.get("key_directory", 
                               str(Path.home() / ".cryptbox" / "keys"))
    
    def set_preference(self, key: str, value: Any):
        """
        Set user preference.
        
        Args:
            key: Preference key
            value: Preference value
        """
        if "preferences" not in self.config:
            self.config["preferences"] = {}
        
        self.config["preferences"][key] = value
        self.save_config()
    
    def get_preference(self, key: str, default: Any = None) -> Any:
        """
        Get user preference.
        
        Args:
            key: Preference key
            default: Default value if not found
            
        Returns:
            Preference value or default
        """
        return self.config.get("preferences", {}).get(key, default)
    
    def list_encrypted_files(self) -> list:
        """
        List all files with custom configurations.
        
        Returns:
            List of file paths
        """
        return list(self.config.get("files", {}).keys())
    
    def export_config(self, export_path: str, include_passwords: bool = False):
        """
        Export configuration to file.
        
        Args:
            export_path: Path to export file
            include_passwords: Whether to include passwords
        """
        export_config = self.config.copy()
        
        if not include_passwords:
            export_config["default_password"] = "***REDACTED***"
            if "files" in export_config:
                for file_path in export_config["files"]:
                    export_config["files"][file_path]["password"] = "***REDACTED***"
        
        with open(export_path, 'w') as f:
            json.dump(export_config, f, indent=2)
    
    def get_config_summary(self) -> Dict[str, Any]:
        """
        Get configuration summary (without sensitive data).
        
        Returns:
            Configuration summary dictionary
        """
        return {
            "version": self.config.get("version"),
            "mount_point": self.config.get("mount_point"),
            "encrypted_storage": self.config.get("encrypted_storage"),
            "key_directory": self.config.get("key_directory"),
            "has_default_password": bool(self.config.get("default_password")),
            "num_configured_files": len(self.config.get("files", {})),
            "preferences": self.config.get("preferences", {})
        }


# Example usage
if __name__ == "__main__":
    print("=== Cryptbox 2.0 - Configuration Manager Demo ===\n")
    
    # Create config manager (will create default config)
    config_mgr = ConfigManager()
    
    print("1. Initial Configuration:")
    summary = config_mgr.get_config_summary()
    print(json.dumps(summary, indent=2))
    print()
    
    # Set default password
    print("2. Setting Default Password:")
    config_mgr.set_default_password("my_secure_password_123")
    print(f"Default password set: {bool(config_mgr.get_default_password())}")
    print()
    
    # Set file-specific password
    print("3. Setting File-Specific Password:")
    config_mgr.set_file_password(
        "/path/to/secret.txt",
        "file_specific_password",
        public_keys=["key1_public", "key2_public"]
    )
    print(f"File password for secret.txt: {config_mgr.get_file_password('/path/to/secret.txt')}")
    print()
    
    # Set preferences
    print("4. Setting Preferences:")
    config_mgr.set_preference("auto_mount", True)
    config_mgr.set_preference("show_hidden", True)
    print(f"Auto-mount: {config_mgr.get_preference('auto_mount')}")
    print(f"Show hidden: {config_mgr.get_preference('show_hidden')}")
    print()
    
    # List configured files
    print("5. Configured Files:")
    files = config_mgr.list_encrypted_files()
    print(f"Files with custom config: {files}")
    print()
    
    # Export configuration
    print("6. Exporting Configuration:")
    export_path = "/tmp/cryptbox_config_export.json"
    config_mgr.export_config(export_path, include_passwords=False)
    print(f"Config exported to: {export_path}")
    print()
    
    # Show final summary
    print("7. Final Configuration Summary:")
    summary = config_mgr.get_config_summary()
    print(json.dumps(summary, indent=2))
    
    print("\n✅ Configuration manager working correctly!")