"""
Cryptbox 2.0 - FUSE Filesystem Implementation

This module implements the encrypted filesystem using FUSE (Filesystem in Userspace).
Files stored in the __enc__ directory are automatically encrypted/decrypted transparently.
"""

import os
import sys
import errno
import stat
from pathlib import Path
from typing import Optional
from fuse import FUSE, FuseOSError, Operations, LoggingMixIn

from cryptbox.encryption import FileEncryptor
from cryptbox.file_manager import DecryptedFileManager
from cryptbox.config_manager import ConfigManager
from cryptbox.metadata import MetadataManager
from cryptbox.signature import DigitalSignature
from cryptbox.key_manager import RSAKeyManager


class CryptboxFS(LoggingMixIn, Operations):
    """
    Cryptbox Encrypted Filesystem.
    
    Transparently encrypts and decrypts files stored in the __enc__ directory.
    Users interact with decrypted files through the mount point.
    """
    
    def __init__(self, 
                 encrypted_root: str,
                 config_manager: ConfigManager,
                 file_encryptor: FileEncryptor,
                 key_manager: Optional[RSAKeyManager] = None):
        """
        Initialize Cryptbox filesystem.
        
        Args:
            encrypted_root: Path to __enc__ directory
            config_manager: Configuration manager
            file_encryptor: File encryptor instance
            key_manager: Optional RSA key manager for signatures
        """
        self.encrypted_root = Path(encrypted_root)
        self.config_manager = config_manager
        self.file_encryptor = file_encryptor
        
        # Create encrypted root if it doesn't exist
        self.encrypted_root.mkdir(parents=True, exist_ok=True)
        
        # Initialize managers
        self.signature_manager = None
        if key_manager:
            self.signature_manager = DigitalSignature(key_manager)
        
        self.file_manager = DecryptedFileManager(
            file_encryptor,
            self.signature_manager
        )
        
        self.metadata_manager = MetadataManager(
            config_manager.get_default_password() or "default_password"
        )
        
        # File descriptor counter
        self.fd = 0
        self.fd_map = {}  # Maps file descriptors to encrypted paths
    
    def _get_encrypted_path(self, path: str) -> str:
        """
        Convert virtual path to encrypted path.
        
        Args:
            path: Virtual filesystem path
            
        Returns:
            Actual encrypted file path
        """
        # Remove leading slash
        if path.startswith('/'):
            path = path[1:]
        
        # Construct encrypted path
        return str(self.encrypted_root / path)
    
    def _get_password(self, path: str) -> str:
        """
        Get password for a file.
        
        Args:
            path: File path
            
        Returns:
            Password for the file
        """
        password = self.config_manager.get_file_password(path)
        if not password:
            password = self.config_manager.get_default_password()
        if not password:
            raise FuseOSError(errno.EACCES)
        return password
    
    # Filesystem methods
    
    def getattr(self, path, fh=None):
        """
        Get file attributes.
        
        Args:
            path: File path
            fh: File handle (optional)
            
        Returns:
            Dictionary of file attributes
        """
        encrypted_path = self._get_encrypted_path(path)
        
        try:
            st = os.lstat(encrypted_path)
            attrs = dict((key, getattr(st, key)) for key in (
                'st_atime', 'st_ctime', 'st_gid', 'st_mode',
                'st_mtime', 'st_nlink', 'st_size', 'st_uid'
            ))
            
            # If file is open, use decrypted size
            if self.file_manager.is_open(encrypted_path):
                open_file = self.file_manager.get_open_file(encrypted_path)
                if open_file:
                    attrs['st_size'] = open_file.get_size()
            
            return attrs
            
        except FileNotFoundError:
            raise FuseOSError(errno.ENOENT)
    
    def readdir(self, path, fh):
        """
        Read directory contents.
        
        Args:
            path: Directory path
            fh: File handle
            
        Yields:
            Directory entries
        """
        encrypted_path = self._get_encrypted_path(path)
        
        dirents = ['.', '..']
        if os.path.isdir(encrypted_path):
            dirents.extend(os.listdir(encrypted_path))
        
        for entry in dirents:
            yield entry
    
    def mkdir(self, path, mode):
        """
        Create directory.
        
        Args:
            path: Directory path
            mode: Directory permissions
        """
        encrypted_path = self._get_encrypted_path(path)
        os.mkdir(encrypted_path, mode)
    
    def rmdir(self, path):
        """
        Remove directory.
        
        Args:
            path: Directory path
        """
        encrypted_path = self._get_encrypted_path(path)
        os.rmdir(encrypted_path)
    
    def create(self, path, mode, fi=None):
        """
        Create new file.
        
        Args:
            path: File path
            mode: File permissions
            fi: File info (optional)
            
        Returns:
            File descriptor
        """
        encrypted_path = self._get_encrypted_path(path)
        
        # Create empty encrypted file
        with open(encrypted_path, 'wb') as f:
            pass
        
        # Set permissions
        os.chmod(encrypted_path, mode)
        
        # Open the file
        password = self._get_password(path)
        self.file_manager.open(encrypted_path, password)
        
        # Generate file descriptor
        self.fd += 1
        self.fd_map[self.fd] = encrypted_path
        
        return self.fd
    
    def open(self, path, flags):
        """
        Open file.
        
        Args:
            path: File path
            flags: Open flags
            
        Returns:
            File descriptor
        """
        encrypted_path = self._get_encrypted_path(path)
        
        # Get password and open file
        password = self._get_password(path)
        self.file_manager.open(encrypted_path, password)
        
        # Generate file descriptor
        self.fd += 1
        self.fd_map[self.fd] = encrypted_path
        
        return self.fd
    
    def read(self, path, size, offset, fh):
        """
        Read data from file.
        
        Args:
            path: File path
            size: Number of bytes to read
            offset: Byte offset
            fh: File handle
            
        Returns:
            Data read from file
        """
        encrypted_path = self.fd_map.get(fh)
        if not encrypted_path:
            encrypted_path = self._get_encrypted_path(path)
        
        open_file = self.file_manager.get_open_file(encrypted_path)
        if not open_file:
            raise FuseOSError(errno.EBADF)
        
        return open_file.read(offset, size)
    
    def write(self, path, data, offset, fh):
        """
        Write data to file.
        
        Args:
            path: File path
            data: Data to write
            offset: Byte offset
            fh: File handle
            
        Returns:
            Number of bytes written
        """
        encrypted_path = self.fd_map.get(fh)
        if not encrypted_path:
            encrypted_path = self._get_encrypted_path(path)
        
        open_file = self.file_manager.get_open_file(encrypted_path)
        if not open_file:
            raise FuseOSError(errno.EBADF)
        
        return open_file.write(data, offset)
    
    def truncate(self, path, length, fh=None):
        """
        Truncate file to specified length.
        
        Args:
            path: File path
            length: New file length
            fh: File handle (optional)
        """
        encrypted_path = self._get_encrypted_path(path)
        
        open_file = self.file_manager.get_open_file(encrypted_path)
        if open_file:
            open_file.truncate(length)
        else:
            # File not open, need to open, truncate, close
            password = self._get_password(path)
            temp_file = self.file_manager.open(encrypted_path, password)
            temp_file.truncate(length)
            self.file_manager.close(encrypted_path)
    
    def flush(self, path, fh):
        """
        Flush file data.
        
        Args:
            path: File path
            fh: File handle
        """
        encrypted_path = self.fd_map.get(fh)
        if not encrypted_path:
            encrypted_path = self._get_encrypted_path(path)
        
        self.file_manager.flush(encrypted_path)
    
    def release(self, path, fh):
        """
        Release (close) file.
        
        Args:
            path: File path
            fh: File handle
        """
        encrypted_path = self.fd_map.get(fh)
        if encrypted_path:
            self.file_manager.close(encrypted_path)
            del self.fd_map[fh]
    
    def fsync(self, path, datasync, fh):
        """
        Sync file data to disk.
        
        Args:
            path: File path
            datasync: Data sync flag
            fh: File handle
        """
        self.flush(path, fh)
    
    def unlink(self, path):
        """
        Delete file.
        
        Args:
            path: File path
        """
        encrypted_path = self._get_encrypted_path(path)
        
        # Close file if open
        if self.file_manager.is_open(encrypted_path):
            self.file_manager.close(encrypted_path)
        
        # Remove file
        os.unlink(encrypted_path)
        
        # Remove from config
        self.config_manager.remove_file_config(path)
    
    def rename(self, old, new):
        """
        Rename file.
        
        Args:
            old: Old path
            new: New path
        """
        old_encrypted = self._get_encrypted_path(old)
        new_encrypted = self._get_encrypted_path(new)
        
        os.rename(old_encrypted, new_encrypted)
    
    def chmod(self, path, mode):
        """
        Change file permissions.
        
        Args:
            path: File path
            mode: New permissions
        """
        encrypted_path = self._get_encrypted_path(path)
        os.chmod(encrypted_path, mode)
    
    def chown(self, path, uid, gid):
        """
        Change file ownership.
        
        Args:
            path: File path
            uid: User ID
            gid: Group ID
        """
        encrypted_path = self._get_encrypted_path(path)
        os.chown(encrypted_path, uid, gid)
    
    def destroy(self, path):
        """
        Cleanup on filesystem unmount.
        
        Args:
            path: Filesystem path
        """
        # Close all open files
        self.file_manager.close_all()


def mount_cryptbox(mount_point: str,
                   encrypted_root: str,
                   config_path: Optional[str] = None,
                   foreground: bool = False):
    """
    Mount Cryptbox filesystem.
    
    Args:
        mount_point: Where to mount the filesystem
        encrypted_root: Path to __enc__ directory
        config_path: Path to config file
        foreground: Run in foreground (for debugging)
    """
    # Initialize managers
    config_manager = ConfigManager(config_path)
    file_encryptor = FileEncryptor()
    
    # Initialize key manager if keys exist
    key_manager = None
    key_dir = config_manager.get_key_directory()
    private_key_path = Path(key_dir) / "private_key.pem"
    public_key_path = Path(key_dir) / "public_key.pem"
    
    if private_key_path.exists() and public_key_path.exists():
        key_manager = RSAKeyManager(str(private_key_path), str(public_key_path))
        key_manager.load_keys()
    
    # Create filesystem
    cryptbox_fs = CryptboxFS(
        encrypted_root,
        config_manager,
        file_encryptor,
        key_manager
    )
    
    # Mount filesystem
    print(f"Mounting Cryptbox at: {mount_point}")
    print(f"Encrypted storage: {encrypted_root}")
    print(f"Press Ctrl+C to unmount")
    
    FUSE(cryptbox_fs, mount_point, nothreads=True, foreground=foreground)


# Example usage
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python filesystem.py <mount_point> <encrypted_root>")
        print("Example: python filesystem.py ~/cryptbox_mount ~/Dropbox/cryptbox/__enc__")
        sys.exit(1)
    
    mount_point = sys.argv[1]
    encrypted_root = sys.argv[2]
    
    # Create directories if they don't exist
    Path(mount_point).mkdir(parents=True, exist_ok=True)
    Path(encrypted_root).mkdir(parents=True, exist_ok=True)
    
    # Mount filesystem
    mount_cryptbox(mount_point, encrypted_root, foreground=True)